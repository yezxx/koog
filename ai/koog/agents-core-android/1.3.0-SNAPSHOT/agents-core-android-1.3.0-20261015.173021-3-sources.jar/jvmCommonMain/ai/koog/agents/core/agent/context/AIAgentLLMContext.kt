@file:Suppress("MissingKDocForPublicAPI", "EXPECT_ACTUAL_CLASSIFIERS_ARE_IN_BETA_WARNING")
@file:OptIn(InternalAgentsApi::class, InternalKoogUtils::class)

package ai.koog.agents.core.agent.context

import ai.koog.agents.annotations.JavaAPI
import ai.koog.agents.core.agent.config.AIAgentConfig
import ai.koog.agents.core.agent.session.AIAgentLLMReadSession
import ai.koog.agents.core.agent.session.AIAgentLLMWriteSession
import ai.koog.agents.core.annotation.InternalAgentsApi
import ai.koog.agents.core.environment.AIAgentEnvironment
import ai.koog.agents.core.tools.ToolDescriptor
import ai.koog.agents.core.tools.ToolRegistry
import ai.koog.agents.core.utils.runBlockingOnStrategyDispatcher
import ai.koog.prompt.Prompt
import ai.koog.prompt.executor.model.PromptExecutor
import ai.koog.prompt.llm.LLModel
import ai.koog.prompt.processor.ResponseProcessor
import ai.koog.utils.annotations.InternalKoogUtils
import ai.koog.utils.time.KoogClock
import java.util.function.Function

public actual open class AIAgentLLMContext actual constructor(
    tools: List<ToolDescriptor>,
    toolRegistry: ToolRegistry,
    prompt: Prompt,
    model: LLModel,
    responseProcessor: ResponseProcessor?,
    promptExecutor: PromptExecutor,
    environment: AIAgentEnvironment,
    config: AIAgentConfig,
    clock: KoogClock
) : AIAgentLLMContextCommon(
    initialTools = tools,
    initialToolRegistry = toolRegistry,
    initialPrompt = prompt,
    initialModel = model,
    initialResponseProcessor = responseProcessor,
    initialPromptExecutor = promptExecutor,
    initialEnvironment = environment,
    initialConfig = config,
    initialClock = clock
) {
    @JvmOverloads
    public override suspend fun copy(
        tools: List<ToolDescriptor>,
        toolRegistry: ToolRegistry,
        prompt: Prompt,
        model: LLModel,
        responseProcessor: ResponseProcessor?,
        promptExecutor: PromptExecutor,
        environment: AIAgentEnvironment,
        config: AIAgentConfig,
        clock: KoogClock
    ): AIAgentLLMContext =
        super.copy(tools, toolRegistry, prompt, model, responseProcessor, promptExecutor, environment, config, clock)

    /**
     * Executes a block of code within a write session for the AI Agent LLM context.
     *
     * This function provides a mechanism to modify or interact with the AI Agent's state in a mutable
     * manner, ensuring proper synchronization and execution within the main dispatcher.
     *
     * @param T The return type of the operation performed within the write session.
     * @param block A function that takes an instance of `AIAgentLLMWriteSession` as its receiver and
     *              performs operations on it. The result of this block is the return value of the enclosing function.
     * @return The result produced by the provided block of code.
     */
    @JavaAPI
    public fun <T> writeSession(block: Function<AIAgentLLMWriteSession, T>): T = config.runBlockingOnStrategyDispatcher {
        writeSession {
            block.apply(this)
        }
    }

    /**
     * Executes a read-only session within the context of `AIAgentLLMReadSession` and returns the result of the provided block.
     *
     * This method is designed for Java interop and facilitates read operations on the `AIAgentLLMReadSession`,
     * ensuring the provided block is executed within the specified context.
     *
     * @param block A function that performs actions within the `AIAgentLLMReadSession` and computes a result of type `T`.
     * @return The result of executing the provided block within the `AIAgentLLMReadSession` context.
     */
    @JavaAPI
    public fun <T> readSession(block: Function<AIAgentLLMReadSession, T>): T = config.runBlockingOnStrategyDispatcher {
        readSession {
            block.apply(this)
        }
    }

    @JvmOverloads
    public override fun copy(
        tools: List<ToolDescriptor>,
        prompt: Prompt,
        model: LLModel,
        responseProcessor: ResponseProcessor?,
        promptExecutor: PromptExecutor,
        environment: AIAgentEnvironment,
        config: AIAgentConfig,
        clock: KoogClock
    ): AIAgentLLMContext =
        super.copy(tools, prompt, model, responseProcessor, promptExecutor, environment, config, clock)
}
