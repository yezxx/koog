package ai.koog.agents.snapshot.feature

import ai.koog.agents.annotations.JavaAPI
import ai.koog.agents.core.agent.AIAgent
import ai.koog.agents.core.agent.config.AIAgentConfig
import ai.koog.agents.core.agent.context.AIAgentContext
import ai.koog.agents.core.agent.context.GraphAgentContextData
import ai.koog.agents.core.agent.context.RollbackStrategy
import ai.koog.agents.core.agent.context.featureOrThrow
import ai.koog.agents.core.agent.context.graphAgentContextDataAdditionalKey
import ai.koog.agents.core.agent.context.store
import ai.koog.agents.core.agent.entity.AIAgentGraphStrategy
import ai.koog.agents.core.agent.entity.AIAgentStorage
import ai.koog.agents.core.agent.entity.AIAgentStorageKey
import ai.koog.agents.core.agent.entity.AIAgentSubgraphBase
import ai.koog.agents.core.agent.entity.createStorageKey
import ai.koog.agents.core.agent.execution.DEFAULT_AGENT_PATH_SEPARATOR
import ai.koog.agents.core.agent.session.AIAgentRunSession
import ai.koog.agents.core.agent.session.AdditionalInputs
import ai.koog.agents.core.agent.session.feature
import ai.koog.agents.core.annotation.InternalAgentsApi
import ai.koog.agents.core.feature.AIAgentGraphFeature
import ai.koog.agents.core.feature.AIAgentPlannerFeature
import ai.koog.agents.core.feature.pipeline.AIAgentGraphPipeline
import ai.koog.agents.core.feature.pipeline.AIAgentPlannerPipeline
import ai.koog.agents.core.planner.AIAgentPlannerStrategy
import ai.koog.agents.core.planner.PlannerAgentExecutionPoint
import ai.koog.agents.core.tools.annotations.InternalAgentToolsApi
import ai.koog.agents.snapshot.providers.PersistenceStorageProvider
import ai.koog.prompt.message.Message
import ai.koog.prompt.message.MessagePart
import ai.koog.serialization.JSONElement
import ai.koog.serialization.JSONObject
import ai.koog.serialization.JSONSerializer
import ai.koog.serialization.TypeToken
import ai.koog.serialization.kotlinx.toKoogJSONObject
import ai.koog.utils.time.KoogClock
import io.github.oshai.kotlinlogging.KotlinLogging
import kotlin.coroutines.cancellation.CancellationException
import kotlin.jvm.JvmName
import kotlin.jvm.JvmOverloads
import kotlin.jvm.JvmStatic
import kotlin.jvm.JvmSynthetic
import kotlin.time.ExperimentalTime
import kotlin.time.Instant
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

/**
 * Bridges a suspending [block] into a blocking call for Java interop.
 *
 * On JVM/Android this dispatches through [AIAgentConfig.strategyDispatcher] via
 * [runBlockingReentrant]; on non-JVM targets this throws [UnsupportedOperationException]
 * because Kotlin lacks a portable blocking primitive.
 */
internal expect fun <T> runBlockingOnStrategy(
    agentConfig: AIAgentConfig,
    block: suspend () -> T,
): T

/**
 * A feature that provides checkpoint functionality for AI agents.
 *
 * This class allows saving and restoring the state of an agent at specific points during execution.
 * Checkpoints capture the agent's message history, current node, and input data, enabling:
 * - Resuming agent execution from a specific point
 * - Rolling back to previous states
 * - Persisting agent state across sessions
 *
 * The feature can be configured to automatically create checkpoints after each node execution
 * using the [PersistenceFeatureConfig.enableAutomaticPersistence] option.
 *
 * @property persistenceStorageProvider The provider responsible for storing and retrieving checkpoints
 * @property serializer The JSON serializer.
 * @property clock The clock used for timestamping checkpoints
 */
@OptIn(ExperimentalUuidApi::class, ExperimentalTime::class, InternalAgentsApi::class)
public class Persistence(
    private val persistenceStorageProvider: PersistenceStorageProvider<*>,
    internal val serializer: JSONSerializer,
    internal val clock: KoogClock = KoogClock.System,
) {
    /**
     * Determines the strategy to use during rollback operations for the agent's state.
     *
     * The `rollbackStrategy` defines the extent of state restoration when rolling back
     * to a previous checkpoint. It impacts which parts of the agent's session data
     * (e.g., message history, context) are restored during a rollback. Available
     * strategies include restoring the full state or limiting restoration to specific parts.
     *
     * By default, the strategy is set to [RollbackStrategy.Default], which restores the
     * entire context of the agent, including message history and other stateful data.
     * Alternative strategies, such as `MessageHistoryOnly`, can be used for partial rollbacks.
     */
    public var rollbackStrategy: RollbackStrategy = RollbackStrategy.Default

    /**
     * A registry for managing rollback tools within the persistence system.
     *
     * The `rollbackToolRegistry` plays a key role in supporting the rollback mechanism in the
     * persistence operations, allowing seamless state restoration for tools **with side-effects** to specified or latest
     * checkpoints as needed.
     *
     */
    public var rollbackToolRegistry: RollbackToolRegistry = RollbackToolRegistry {}

    /**
     * Companion object implementing agent feature, handling [Persistence] creation and installation.
     */
    public companion object Feature :
        AIAgentGraphFeature<PersistenceFeatureConfig, Persistence>,
        AIAgentPlannerFeature<PersistenceFeatureConfig, Persistence> {

        private val logger = KotlinLogging.logger { }

        override val key: AIAgentStorageKey<Persistence> = createStorageKey<Persistence>("agents-features-snapshot")

        override fun createInitialConfig(
            agentConfig: AIAgentConfig
        ): PersistenceFeatureConfig = PersistenceFeatureConfig()

        override fun install(
            config: PersistenceFeatureConfig,
            pipeline: AIAgentGraphPipeline,
        ): Persistence {
            val persistence = Persistence(config.storage, pipeline.config.serializer)
            persistence.rollbackToolRegistry = config.rollbackToolRegistry

            pipeline.interceptStrategyStarting(this) { ctx ->
                val strategy = ctx.strategy as AIAgentGraphStrategy<*, *>

                require(strategy.metadata.uniqueNames) {
                    "Checkpoint feature requires unique node names in the strategy metadata"
                }

                val checkpoint = persistence.rollbackToLatestCheckpoint(ctx.context)

                if (checkpoint != null) {
                    val nodePath = checkpoint.graphProperties?.nodePath
                    logger.info { "Restoring checkpoint: ${checkpoint.checkpointId} to node $nodePath" }
                } else {
                    logger.info { "No non-tombstone checkpoint found, starting from the beginning" }
                }
            }

            pipeline.interceptNodeExecutionCompleted(this) { eventCtx ->
                if (persistence.isTechnicalNode(eventCtx.node.id)) {
                    return@interceptNodeExecutionCompleted
                }

                if (config.enableAutomaticPersistence) {
                    val parent = persistence.getLatestCheckpoint(eventCtx.context.runId)
                    persistence.createCheckpointAfterNode(
                        agentContext = eventCtx.context,
                        nodePath = eventCtx.context.executionInfo.path(),
                        lastOutput = eventCtx.output,
                        lastOutputType = eventCtx.outputType,
                        version = parent?.version?.plus(1) ?: 0L,
                    )
                }
            }

            pipeline.interceptStrategyCompleted(this) { ctx ->
                if (config.enableAutomaticPersistence) {
                    val parent = persistence.getLatestCheckpoint(ctx.context.runId)
                    persistence.createTombstoneCheckpoint(
                        ctx.context.runId,
                        persistence.clock.now(),
                        parent?.version?.plus(1) ?: 0L
                    )
                }
            }

            return persistence
        }

        override fun install(config: PersistenceFeatureConfig, pipeline: AIAgentPlannerPipeline): Persistence {
            val persistence = Persistence(config.storage, pipeline.config.serializer)
            persistence.rollbackToolRegistry = config.rollbackToolRegistry

            pipeline.interceptStrategyStarting(this) { ctx ->
                val planner = (ctx.strategy as AIAgentPlannerStrategy<*, *>).planner

                require(planner.stateType != null && planner.planType != null) {
                    "State and plan types must be explicitly specified for the planner persistence"
                }

                val checkpoint = persistence.rollbackToLatestCheckpoint(ctx.context)

                if (checkpoint != null) {
                    logger.info { "Restoring checkpoint: ${checkpoint.checkpointId}" }
                } else {
                    logger.info { "No non-tombstone checkpoint found, starting from the beginning" }
                }
            }

            if (config.enableAutomaticPersistence) {
                // if any of the type tokens are null, onStrategyStarting will fail

                pipeline.interceptPlanCreationCompleted(this) { eventCtx ->
                    val parent = persistence.getLatestCheckpoint(eventCtx.context.runId)
                    persistence.createPlannerCheckpoint(
                        agentContext = eventCtx.context,
                        state = eventCtx.state,
                        stateType = eventCtx.stateType!!,
                        plan = eventCtx.updatedPlan,
                        planType = eventCtx.planType!!,
                        executionPoint = PlannerAgentExecutionPoint.PlanCreated,
                        version = parent?.version?.plus(1) ?: 0L,
                    )
                }

                pipeline.interceptStepExecutionCompleted(this) { eventCtx ->
                    val parent = persistence.getLatestCheckpoint(eventCtx.context.runId)
                    persistence.createPlannerCheckpoint(
                        agentContext = eventCtx.context,
                        state = eventCtx.state,
                        stateType = eventCtx.stateType!!,
                        plan = eventCtx.plan,
                        planType = eventCtx.planType!!,
                        executionPoint = PlannerAgentExecutionPoint.StepExecuted,
                        version = parent?.version?.plus(1) ?: 0L,
                    )
                }

                pipeline.interceptPlanCompletionEvaluationCompleted(this) { eventCtx ->
                    val parent = persistence.getLatestCheckpoint(eventCtx.context.runId)
                    persistence.createPlannerCheckpoint(
                        agentContext = eventCtx.context,
                        state = eventCtx.state,
                        stateType = eventCtx.stateType!!,
                        plan = eventCtx.plan,
                        planType = eventCtx.planType!!,
                        executionPoint = PlannerAgentExecutionPoint.PlanCompletionEvaluated(eventCtx.isCompleted),
                        version = parent?.version?.plus(1) ?: 0L,
                    )
                }

                pipeline.interceptStrategyCompleted(this) { ctx ->
                    val parent = persistence.getLatestCheckpoint(ctx.context.runId)
                    persistence.createTombstoneCheckpoint(
                        ctx.context.runId,
                        persistence.clock.now(),
                        parent?.version?.plus(1) ?: 0L
                    )
                }
            }

            return persistence
        }

        /**
         * Runs the agent from a previously saved checkpoint.
         *
         * Creates a new session and injects the checkpoint data into the session's storage so that the agent's
         * graph strategy restores execution from the checkpoint's position. The [Persistence] feature does
         * **not** need to be installed on the agent for this to work.
         *
         * @param agent The agent to run.
         * @param input The input to provide to the agent.
         * @param checkpoint The checkpoint data to restore from.
         * @param rollbackStrategy The strategy to use when restoring state. Defaults to [RollbackStrategy.Default].
         * @param sessionId Optional session identifier. A random UUID is generated if not provided.
         * @return The output produced by the agent after resuming from the checkpoint.
         */
        @JvmSynthetic
        public suspend fun <Input, Output> runFromCheckpoint(
            agent: AIAgent<Input, Output>,
            input: Input,
            checkpoint: AgentCheckpointData,
            rollbackStrategy: RollbackStrategy = RollbackStrategy.Default,
            sessionId: String? = null,
        ): Output {
            val session = agent.createSession(sessionId)
            return runFromCheckpoint(session, input, checkpoint, rollbackStrategy)
        }

        /**
         * Runs the session from a previously saved checkpoint.
         *
         * Injects the checkpoint data into the session's storage so that the agent's graph strategy
         * restores execution from the checkpoint's position. The [Persistence] feature does **not** need
         * to be installed on the agent for this to work.
         *
         * @param session The session to run.
         * @param input The input to provide to the session.
         * @param checkpoint The checkpoint data to restore from.
         * @param rollbackStrategy The strategy to use when restoring state. Defaults to [RollbackStrategy.Default].
         * @return The output produced by the session after resuming from the checkpoint.
         */
        @JvmSynthetic
        public suspend fun <Input, Output, TContext : AIAgentContext> runFromCheckpoint(
            session: AIAgentRunSession<Input, Output, TContext>,
            input: Input,
            checkpoint: AgentCheckpointData,
            rollbackStrategy: RollbackStrategy = RollbackStrategy.Default,
        ): Output {
            val serializer = session.pipeline()?.config?.serializer ?: throw IllegalStateException("Agent config not found in session pipeline")
            val storage = AIAgentStorage(serializer)
            storage.set(graphAgentContextDataAdditionalKey, checkpoint.toAgentContextData(rollbackStrategy) as GraphAgentContextData)
            return session.run(input, AdditionalInputs.Storage(storage))
        }

        /**
         * Blocking variant of [runFromCheckpoint] intended for Java callers. Only available on JVM/Android.
         *
         * @see runFromCheckpoint
         */
        @JavaAPI
        @JvmStatic
        @JvmOverloads
        @JvmName("runFromCheckpoint")
        public fun <Input, Output> runFromCheckpointBlocking(
            agent: AIAgent<Input, Output>,
            agentInput: Input,
            checkpoint: AgentCheckpointData,
            rollbackStrategy: RollbackStrategy = RollbackStrategy.Default,
            sessionId: String? = null,
        ): Output = runBlockingOnStrategy(agent.agentConfig) {
            runFromCheckpoint(agent, agentInput, checkpoint, rollbackStrategy, sessionId)
        }
    }

    private fun isTechnicalNode(nodeId: String): Boolean =
        nodeId.startsWith(AIAgentSubgraphBase.FINISH_NODE_PREFIX) ||
            nodeId.startsWith(AIAgentSubgraphBase.START_NODE_PREFIX)

    /**
     * Creates a checkpoint of the agent's current state.
     *
     * This method captures the agent's message history, current node, and input data
     * and stores it as a checkpoint using the configured storage provider.
     *
     * @param agentContext The context of the agent containing the state to checkpoint
     * @param nodePath The path to the node where the checkpoint is created
     * @param lastInput The latest node input data to include in the checkpoint
     * @param checkpointId Optional ID for the checkpoint; a random UUID is generated if not provided
     * @return The created checkpoint data
     */
    /**
     * Creates a checkpoint of the agent's current state.
     *
     * This method captures the agent's message history, current node, and input data
     * and stores it as a checkpoint using the configured storage provider.
     *
     * @param agentContext The context of the agent containing the state to checkpoint
     * @param nodePath The path to the node where the checkpoint is created
     * @param lastOutput The latest node output data to include in the checkpoint
     * @param checkpointId Optional ID for the checkpoint; a random UUID is generated if not provided
     * @return The created checkpoint data
     */
    public suspend fun createCheckpointAfterNode(
        agentContext: AIAgentContext,
        nodePath: String,
        lastOutput: Any?,
        lastOutputType: TypeToken,
        version: Long,
        checkpointId: String? = null,
    ): AgentCheckpointData? {
        val outputJson = try {
            serializer.encodeToJSONElement(lastOutput, lastOutputType)
        } catch (_: Exception) {
            null
        }

        if (outputJson == null) {
            logger.warn {
                "Failed to serialize output of type $lastOutputType for checkpoint creation for $nodePath, skipping..."
            }
            return null
        }

        val checkpoint = agentContext.llm.readSession {
            AgentCheckpointData(
                checkpointId = checkpointId ?: Uuid.random().toString(),
                messageHistory = prompt.messages,
                llmParams = prompt.params,
                llmModel = model,
                tools = tools.map { it.name },
                storage = JSONObject(agentContext.storage.toSerializedMap()),
                agentIterations = agentContext.stateManager.withStateLock { it.iterations },
                createdAt = clock.now(),
                version = version,
                graphProperties = GraphCheckpointProperties(
                    nodePath = nodePath,
                    lastOutput = outputJson
                )
            )
        }

        saveCheckpoint(agentContext.runId, checkpoint)
        return checkpoint
    }

    /**
     * Creates a checkpoint of the agent's current state.
     *
     * This method captures the agent's message history, current state, and plan.
     *
     * @param agentContext The context of the agent to checkpoint.
     * @param state The current state of the agent.
     * @param plan The current plan of the agent.
     * @param executionPoint The execution point of the planner agent.
     */
    public suspend fun createPlannerCheckpoint(
        agentContext: AIAgentContext,
        state: Any,
        stateType: TypeToken,
        plan: Any,
        planType: TypeToken,
        executionPoint: PlannerAgentExecutionPoint,
        version: Long,
        checkpointId: String? = null,
    ): AgentCheckpointData? {
        val stateJson = try {
            agentContext.config.serializer.encodeToJSONElement(state, stateType)
        } catch (_: Exception) {
            logger.warn { "Failed to serialize state for planner checkpoint, skipping checkpoint creation..." }
            return null
        }

        val planJson = try {
            agentContext.config.serializer.encodeToJSONElement(plan, planType)
        } catch (_: Exception) {
            logger.warn { "Failed to serialize plan for planner checkpoint, skipping checkpoint creation..." }
            return null
        }

        val checkpoint = agentContext.llm.readSession {
            AgentCheckpointData(
                checkpointId = checkpointId ?: Uuid.random().toString(),
                messageHistory = prompt.messages,
                llmParams = prompt.params,
                llmModel = model,
                tools = tools.map { it.name },
                storage = JSONObject(agentContext.storage.toSerializedMap()),
                agentIterations = agentContext.stateManager.withStateLock { it.iterations },
                createdAt = clock.now(),
                version = version,
                plannerProperties = PlannerCheckpointProperties(
                    executionPoint = executionPoint,
                    state = stateJson,
                    plan = planJson
                )
            )
        }

        saveCheckpoint(agentContext.runId, checkpoint)
        return checkpoint
    }

    /**
     * Creates and saves a tombstone checkpoint for an agent's session.
     *
     * A tombstone checkpoint represents a placeholder state with no interactions or messages,
     * marking a terminated or invalid session. The method generates the tombstone checkpoint
     * and persists it using the appropriate storage mechanism.
     *
     * @return The created tombstone checkpoint data.
     */
    @InternalAgentsApi
    public suspend fun createTombstoneCheckpoint(runId: String, time: Instant, parentId: Long): AgentCheckpointData {
        val checkpoint = tombstoneCheckpoint(time, parentId)
        saveCheckpoint(runId, checkpoint)
        return checkpoint
    }

    /**
     * Saves a checkpoint using the configured storage provider.
     *
     * @param checkpointData The checkpoint data to save
     */
    public suspend fun saveCheckpoint(runId: String, checkpointData: AgentCheckpointData) {
        persistenceStorageProvider.saveCheckpoint(runId, checkpointData)
    }

    /**
     * Retrieves the latest checkpoint for the specified agent.
     *
     * @return The latest checkpoint data, or null if no checkpoint exists
     */
    public suspend fun getLatestCheckpoint(runId: String): AgentCheckpointData? =
        persistenceStorageProvider.getLatestCheckpoint(runId)

    /**
     * Retrieves a specific checkpoint by ID for the specified agent.
     *
     * @param checkpointId The ID of the checkpoint to retrieve
     * @return The checkpoint data with the specified ID, or null if not found
     */
    public suspend fun getCheckpointById(runId: String, checkpointId: String): AgentCheckpointData? {
        val allCps = persistenceStorageProvider.getCheckpoints(runId)
        return allCps.firstOrNull { it.checkpointId == checkpointId }
    }

    /**
     * Sets the execution point of an agent to a specified state.
     *
     * This method updates the agent's context to start execution from a specific point
     * in its graph, using the provided message history and finished node output data.
     *
     * @param agentContext The context of the agent to modify.
     * @param nodePath The path to the node inside the agent's graph where execution will begin.
     * @param messageHistory The sequence of messages representing the agent's prior interactions.
     * @param output The output data to associate with the specified execution point.
     */
    public suspend fun setExecutionPointAfterNode(
        agentContext: AIAgentContext,
        nodePath: String,
        messageHistory: List<Message>,
        output: JSONElement,
    ) {
        agentContext.llm.readSession {
            agentContext.store(
                GraphAgentContextData(
                    messageHistory = messageHistory,
                    llmParams = prompt.params,
                    llmModel = model,
                    tools = tools.map { it.name },
                    storage = JSONObject(agentContext.storage.toSerializedMap()),
                    agentIterations = agentContext.stateManager.withStateLock { it.iterations },
                    nodePath = agentContext.agentId + DEFAULT_AGENT_PATH_SEPARATOR + nodePath,
                    lastOutput = output,
                    rollbackStrategy = rollbackStrategy
                )
            )
        }
    }

    /**
     * Rolls back an agent's state to a specific checkpoint.
     *
     * This method retrieves the checkpoint with the specified ID and, if found,
     * sets the agent's context to the state captured in that checkpoint.
     *
     * **Note: If some of your tools had side-effects and you need to roll back to some older state, please consider
     * providing [RollbackToolRegistry]. This would only work if you are always trying to rollback BACKWARDS in time!**
     *
     * @param checkpointId The ID of the checkpoint to roll back to
     * @param agentContext The context of the agent to roll back
     * @return The checkpoint data that was restored or null if the checkpoint was not found
     */
    @OptIn(InternalAgentToolsApi::class)
    public suspend fun rollbackToCheckpoint(
        checkpointId: String,
        agentContext: AIAgentContext
    ): AgentCheckpointData? {
        val checkpoint = getCheckpointById(agentContext.runId, checkpointId) ?: return null

        val rollbackAction: suspend (AIAgentContext) -> Unit = { context ->
            messageHistoryDiff(
                currentMessages = context.llm.readSession { prompt.messages },
                checkpointMessages = checkpoint.messageHistory
            )
                .flatMap { it.parts.filterIsInstance<MessagePart.Tool.Call>() }
                .reversed()
                .forEach { toolCall ->
                    rollbackToolRegistry.getRollbackTool(toolCall.tool)?.let { rollbackTool ->
                        val toolArgs = try {
                            toolCall.argsJson
                                .toKoogJSONObject()
                                .let { rollbackTool.decodeArgs(it, serializer) }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (_: Exception) {
                            null
                        }
                        rollbackTool.executeUnsafe(toolArgs)
                    }
                }
        }

        val contextData = checkpoint.toAgentContextData(rollbackStrategy, rollbackAction) ?: return null
        agentContext.store(contextData)
        return checkpoint
    }

    /**
     * Returns the difference only.
     * ex: current messages: [1, 2, 3, 4, 5, 6, 7], checkpoint messages: [1, 2, 3, 4, 5] -> diff messages: 6, 7
     *
     * Only works for the scenario when the current chat history is AHEAD of the checkpoint (i.e. we are restoring BACKWARDS in time),
     *  otherwise it will return an empty list!
     * */
    private fun messageHistoryDiff(currentMessages: List<Message>, checkpointMessages: List<Message>): List<Message> {
        if (checkpointMessages.size > currentMessages.size) {
            return emptyList()
        }

        checkpointMessages.forEachIndexed { index, message ->
            if (currentMessages[index] != message) {
                return emptyList()
            }
        }

        return currentMessages.takeLast(currentMessages.size - checkpointMessages.size)
    }

    /**
     * Rolls back an agent's state to the latest checkpoint.
     *
     * This method retrieves the most recent checkpoint for the agent and,
     * if found, sets the agent's context to the state captured in that checkpoint.
     *
     * @param agentContext The context of the agent to roll back
     * @return The checkpoint data that was restored or null if no checkpoint was found
     */
    public suspend fun rollbackToLatestCheckpoint(
        agentContext: AIAgentContext
    ): AgentCheckpointData? {
        val checkpoint = getLatestCheckpoint(agentContext.runId)
        val contextData = checkpoint?.toAgentContextData(rollbackStrategy) ?: return null
        agentContext.store(contextData)
        return checkpoint
    }
}

/**
 * Extension function to access the checkpoint feature from an agent context.
 *
 * @return The [Persistence] feature instance for this agent
 * @throws IllegalStateException if the checkpoint feature is not installed
 */
public fun AIAgentContext.persistence(): Persistence = featureOrThrow(Persistence)

/**
 * Executes the provided action within the context of the AI agent's persistence layer.
 *
 * This function enhances agents with persistent state management capabilities by leveraging the [Persistence component
 * within the current [AIAgentContext]. The supplied action is executed with the persistence layer, enabling operations
 * that require consistent and reliable state management across the lifecycle of the agent.
 *
 * @param action A suspendable lambda function that receives the [Persistence] instance and the current [AIAgentContext]
 *               as its parameters. This allows custom logic that interacts with the persistence layer to be executed.
 * @return A result of type [T] produced by the execution of the provided action.
 */
public suspend fun <T> AIAgentContext.withPersistence(
    action: suspend Persistence.(AIAgentContext) -> T
): T = this.persistence().action(this)

/**
 * Extension function to access the checkpoint feature from a session.
 *
 * @return The [Persistence] feature instance for this session
 * @throws IllegalStateException if the checkpoint feature is not installed
 */
public fun <Input, Output, TContext : AIAgentContext> AIAgentRunSession<Input, Output, TContext>.persistence(): Persistence =
    feature(Persistence::class, Persistence)
        ?: throw NoSuchElementException("Feature ${Persistence.key} is not found.")

/**
 * Executes the provided action within the context of the session's persistence layer if the session is in a running state.
 *
 * This function allows interaction with the persistence mechanism associated with the session, ensuring that
 * the operation is carried out in the correct execution context.
 *
 * @param action A suspending function defining operations to perform using the session's persistence mechanism
 *               and the current agent context.
 * @return The result of the execution of the provided action.
 * @throws IllegalStateException If the session is not in a running state when this function is called.
 */
@OptIn(InternalAgentsApi::class)
public suspend fun <Input, Output, TContext : AIAgentContext, T> AIAgentRunSession<Input, Output, TContext>.withPersistence(
    action: suspend Persistence.(AIAgentContext) -> T
): T = this.persistence().action(this.context())
