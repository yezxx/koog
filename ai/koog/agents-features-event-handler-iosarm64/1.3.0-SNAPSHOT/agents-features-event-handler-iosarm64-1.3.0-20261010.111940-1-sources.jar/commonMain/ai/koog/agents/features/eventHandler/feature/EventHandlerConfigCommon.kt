package ai.koog.agents.features.eventHandler.feature

import ai.koog.agents.core.feature.config.FeatureConfig
import ai.koog.agents.core.feature.handler.agent.AgentClosingContext
import ai.koog.agents.core.feature.handler.agent.AgentCompletedContext
import ai.koog.agents.core.feature.handler.agent.AgentExecutionFailedContext
import ai.koog.agents.core.feature.handler.agent.AgentStartingContext
import ai.koog.agents.core.feature.handler.llm.LLMCallCompletedContext
import ai.koog.agents.core.feature.handler.llm.LLMCallStartingContext
import ai.koog.agents.core.feature.handler.node.NodeExecutionCompletedContext
import ai.koog.agents.core.feature.handler.node.NodeExecutionFailedContext
import ai.koog.agents.core.feature.handler.node.NodeExecutionStartingContext
import ai.koog.agents.core.feature.handler.strategy.StrategyCompletedContext
import ai.koog.agents.core.feature.handler.strategy.StrategyStartingContext
import ai.koog.agents.core.feature.handler.streaming.LLMStreamingCompletedContext
import ai.koog.agents.core.feature.handler.streaming.LLMStreamingFailedContext
import ai.koog.agents.core.feature.handler.streaming.LLMStreamingFrameReceivedContext
import ai.koog.agents.core.feature.handler.streaming.LLMStreamingStartingContext
import ai.koog.agents.core.feature.handler.subgraph.SubgraphExecutionCompletedContext
import ai.koog.agents.core.feature.handler.subgraph.SubgraphExecutionFailedContext
import ai.koog.agents.core.feature.handler.subgraph.SubgraphExecutionStartingContext
import ai.koog.agents.core.feature.handler.tool.ToolCallCompletedContext
import ai.koog.agents.core.feature.handler.tool.ToolCallFailedContext
import ai.koog.agents.core.feature.handler.tool.ToolCallStartingContext
import ai.koog.agents.core.feature.handler.tool.ToolValidationFailedContext
import kotlin.jvm.JvmSynthetic

/**
 * API for the [EventHandlerConfig]
 */
public open class EventHandlerConfigCommon : FeatureConfig() {

    //region Private Agent Handlers

    private var _onAgentStarting: suspend (eventHandler: AgentStartingContext) -> Unit = { _ -> }

    private var _onAgentCompleted: suspend (eventHandler: AgentCompletedContext) -> Unit = { _ -> }

    private var _onAgentExecutionFailed: suspend (eventHandler: AgentExecutionFailedContext) -> Unit = { _ -> }

    private var _onAgentClosing: suspend (eventHandler: AgentClosingContext) -> Unit = { _ -> }

    //endregion Private Agent Handlers

    //region Private Strategy Handlers

    private var _onStrategyStarting: suspend (eventHandler: StrategyStartingContext) -> Unit = { _ -> }

    private var _onStrategyCompleted: suspend (eventHandler: StrategyCompletedContext) -> Unit = { _ -> }

    //endregion Private Strategy Handlers

    //region Private Node Handlers

    private var _onNodeExecutionStarting: suspend (eventHandler: NodeExecutionStartingContext) -> Unit = { _ -> }

    private var _onNodeExecutionCompleted: suspend (eventHandler: NodeExecutionCompletedContext) -> Unit = { _ -> }

    private var _onNodeExecutionFailed: suspend (eventHandler: NodeExecutionFailedContext) -> Unit = { _ -> }

    //endregion Private Node Handlers

    //region Private Subgraph Handlers

    private var _onSubgraphExecutionStarting: suspend (eventHandler: SubgraphExecutionStartingContext) -> Unit =
        { _ -> }

    private var _onSubgraphExecutionCompleted: suspend (eventHandler: SubgraphExecutionCompletedContext) -> Unit =
        { _ -> }

    private var _onSubgraphExecutionFailed: suspend (eventHandler: SubgraphExecutionFailedContext) -> Unit = { _ -> }

    //endregion Private Subgraph Handlers

    //region Private LLM Call Handlers

    private var _onLLMCallStarting: suspend (eventHandler: LLMCallStartingContext) -> Unit = { _ -> }

    private var _onLLMCallCompleted: suspend (eventHandler: LLMCallCompletedContext) -> Unit = { _ -> }

    //endregion Private LLM Call Handlers

    //region Private Tool Call Handlers

    private var _onToolCallStarting: suspend (eventHandler: ToolCallStartingContext) -> Unit = { _ -> }

    private var _onToolValidationFailed: suspend (eventHandler: ToolValidationFailedContext) -> Unit = { _ -> }

    private var _onToolCallFailed: suspend (eventHandler: ToolCallFailedContext) -> Unit = { _ -> }

    private var _onToolCallCompleted: suspend (eventHandler: ToolCallCompletedContext) -> Unit = { _ -> }

    //endregion Private Tool Call Handlers

    //region Private Stream Handlers

    private var _onLLMStreamingStarting: suspend (eventHandler: LLMStreamingStartingContext) -> Unit = { _ -> }

    private var _onLLMStreamingFrameReceived: suspend (eventHandler: LLMStreamingFrameReceivedContext) -> Unit =
        { _ -> }

    private var _onLLMStreamingFailed: suspend (eventHandler: LLMStreamingFailedContext) -> Unit = { _ -> }

    private var _onLLMStreamingCompleted: suspend (eventHandler: LLMStreamingCompletedContext) -> Unit = { _ -> }

    //endregion Private Stream Handlers

    //region Agent Handlers

    /**
     * Append handler called when an agent is started.
     */
    @JvmSynthetic
    public fun onAgentStarting(handler: suspend (eventContext: AgentStartingContext) -> Unit) {
        val originalHandler = this._onAgentStarting
        this._onAgentStarting = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called when an agent finishes execution.
     */
    @JvmSynthetic
    public fun onAgentCompleted(handler: suspend (eventContext: AgentCompletedContext) -> Unit) {
        val originalHandler = this._onAgentCompleted
        this._onAgentCompleted = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called when an error occurs during agent execution.
     */
    @JvmSynthetic
    public fun onAgentExecutionFailed(handler: suspend (eventContext: AgentExecutionFailedContext) -> Unit) {
        val originalHandler = this._onAgentExecutionFailed
        this._onAgentExecutionFailed = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Appends a handler called before an agent is closed. This allows for additional behavior
     * to be executed prior to the agent being closed.
     */
    @JvmSynthetic
    public fun onAgentClosing(handler: suspend (eventContext: AgentClosingContext) -> Unit) {
        val originalHandler = this._onAgentClosing
        this._onAgentClosing = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    //endregion Trigger Agent Handlers

    //region Strategy Handlers

    /**
     * Append handler called when a strategy starts execution.
     */
    @JvmSynthetic
    public fun onStrategyStarting(handler: suspend (eventContext: StrategyStartingContext) -> Unit) {
        val originalHandler = this._onStrategyStarting
        this._onStrategyStarting = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called when a strategy finishes execution.
     */
    @JvmSynthetic
    public fun onStrategyCompleted(handler: suspend (eventContext: StrategyCompletedContext) -> Unit) {
        val originalHandler = this._onStrategyCompleted
        this._onStrategyCompleted = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    //endregion Strategy Handlers

    //region Node Handlers

    /**
     * Append handler called before a node in the agent's execution graph is processed.
     */
    @JvmSynthetic
    public fun onNodeExecutionStarting(handler: suspend (eventContext: NodeExecutionStartingContext) -> Unit) {
        val originalHandler = this._onNodeExecutionStarting
        this._onNodeExecutionStarting = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called after a node in the agent's execution graph has been processed.
     */
    @JvmSynthetic
    public fun onNodeExecutionCompleted(handler: suspend (eventContext: NodeExecutionCompletedContext) -> Unit) {
        val originalHandler = this._onNodeExecutionCompleted
        this._onNodeExecutionCompleted = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called when an error occurs during the execution of a node.
     */
    @JvmSynthetic
    public fun onNodeExecutionFailed(handler: suspend (eventContext: NodeExecutionFailedContext) -> Unit) {
        val originalHandler = this._onNodeExecutionFailed
        this._onNodeExecutionFailed = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    //endregion Node Handlers

    //region Subgraph Handlers

    /**
     * Append handler called before a subgraph in the agent's execution graph is processed.
     */
    @JvmSynthetic
    public fun onSubgraphExecutionStarting(handler: suspend (eventContext: SubgraphExecutionStartingContext) -> Unit) {
        val originalHandler = this._onSubgraphExecutionStarting
        this._onSubgraphExecutionStarting = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called after a subgraph in the agent's execution graph has been processed.
     */
    @JvmSynthetic
    public fun onSubgraphExecutionCompleted(handler: suspend (eventContext: SubgraphExecutionCompletedContext) -> Unit) {
        val originalHandler = this._onSubgraphExecutionCompleted
        this._onSubgraphExecutionCompleted = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called when an error occurs during the execution of a subgraph.
     */
    @JvmSynthetic
    public fun onSubgraphExecutionFailed(handler: suspend (eventContext: SubgraphExecutionFailedContext) -> Unit) {
        val originalHandler = this._onSubgraphExecutionFailed
        this._onSubgraphExecutionFailed = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    //endregion Subgraph Handlers

    //region LLM Call Handlers

    /**
     * Append handler called before a call is made to the language model.
     */
    @JvmSynthetic
    public fun onLLMCallStarting(handler: suspend (eventContext: LLMCallStartingContext) -> Unit) {
        val originalHandler = this._onLLMCallStarting
        this._onLLMCallStarting = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called after a response is received from the language model.
     */
    @JvmSynthetic
    public fun onLLMCallCompleted(handler: suspend (eventContext: LLMCallCompletedContext) -> Unit) {
        val originalHandler = this._onLLMCallCompleted
        this._onLLMCallCompleted = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    //endregion LLM Call Handlers

    //region Tool Call Handlers

    /**
     * Append handler called when a tool is about to be called.
     */
    @JvmSynthetic
    public fun onToolCallStarting(handler: suspend (eventContext: ToolCallStartingContext) -> Unit) {
        val originalHandler = this._onToolCallStarting
        this._onToolCallStarting = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called when a validation error occurs during a tool call.
     */
    @JvmSynthetic
    public fun onToolValidationFailed(handler: suspend (eventContext: ToolValidationFailedContext) -> Unit) {
        val originalHandler = this._onToolValidationFailed
        this._onToolValidationFailed = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called when a tool call fails with an exception.
     */
    @JvmSynthetic
    public fun onToolCallFailed(handler: suspend (eventContext: ToolCallFailedContext) -> Unit) {
        val originalHandler = this._onToolCallFailed
        this._onToolCallFailed = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Append handler called when a tool call completes successfully.
     */
    @JvmSynthetic
    public fun onToolCallCompleted(handler: suspend (eventContext: ToolCallCompletedContext) -> Unit) {
        val originalHandler = this._onToolCallCompleted
        this._onToolCallCompleted = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    //endregion Tool Call Handlers

    //region Stream Handlers

    /**
     * Registers a handler to be invoked before streaming from a language model begins.
     *
     * This handler is called immediately before starting a streaming operation,
     * allowing you to perform preprocessing, validation, or logging of the streaming request.
     *
     * @param handler The handler function that receives a [LLMStreamingStartingContext] containing
     *                the run ID, prompt, model, and available tools for the streaming session.
     *
     * Example:
     * ```
     * onLLMStreamingStarting { eventContext ->
     *     logger.info("Starting stream for run: ${eventContext.runId}")
     *     logger.debug("Prompt: ${eventContext.prompt}")
     * }
     * ```
     */
    @JvmSynthetic
    public fun onLLMStreamingStarting(handler: suspend (eventContext: LLMStreamingStartingContext) -> Unit) {
        val originalHandler = this._onLLMStreamingStarting
        this._onLLMStreamingStarting = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Registers a handler to be invoked when stream frames are received during streaming.
     *
     * This handler is called for each stream frame as it arrives from the language model,
     * enabling real-time processing, monitoring, or aggregation of streaming content.
     *
     * @param handler The handler function that receives a [LLMStreamingFrameReceivedContext] containing
     *                the run ID and the stream frame with partial response data.
     *
     * Example:
     * ```
     * onLLMStreamingFrameReceived { eventContext ->
     *     when (val frame = eventContext.streamFrame) {
     *         is StreamFrame.Append -> processText(frame.text)
     *         is StreamFrame.ToolCall -> processTool(frame)
     *     }
     * }
     * ```
     */
    @JvmSynthetic
    public fun onLLMStreamingFrameReceived(handler: suspend (eventContext: LLMStreamingFrameReceivedContext) -> Unit) {
        val originalHandler = this._onLLMStreamingFrameReceived
        this._onLLMStreamingFrameReceived = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Registers a handler to be invoked when an error occurs during streaming.
     *
     * This handler is called when an error occurs during streaming,
     * allowing you to perform error handling or logging.
     *
     * @param handler The handler function that receives a [LLMStreamingFailedContext] containing
     *                the run ID, prompt, model, and tools that were used for the streaming session.
     *
     * Example:
     * ```
     * onLLMStreamingFailed { eventContext ->
     *     logger.error("Stream error for run: ${eventContext.runId}")
     * }
     * ```
     */
    @JvmSynthetic
    public fun onLLMStreamingFailed(handler: suspend (eventContext: LLMStreamingFailedContext) -> Unit) {
        val originalHandler = this._onLLMStreamingFailed
        this._onLLMStreamingFailed = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    /**
     * Registers a handler to be invoked after streaming from a language model completes.
     *
     * This handler is called when the streaming operation finishes,
     * allowing you to perform post-processing, cleanup, or final logging operations.
     *
     * @param handler The handler function that receives an [LLMStreamingCompletedContext] containing
     *                the run ID, prompt, model, and tools that were used for the streaming session.
     *
     * Example:
     * ```
     * onLLMStreamingCompleted { eventContext ->
     *     logger.info("Stream completed for run: ${eventContext.runId}")
     *     // Perform any cleanup or aggregation of collected stream data
     * }
     * ```
     */
    @JvmSynthetic
    public fun onLLMStreamingCompleted(handler: suspend (eventContext: LLMStreamingCompletedContext) -> Unit) {
        val originalHandler = this._onLLMStreamingCompleted
        this._onLLMStreamingCompleted = { eventContext ->
            originalHandler(eventContext)
            handler.invoke(eventContext)
        }
    }

    //endregion Stream Handlers

    //region Invoke Agent Handlers

    /**
     * Invoke handlers for an event when an agent is started.
     */
    internal suspend fun invokeOnAgentStarting(eventContext: AgentStartingContext) {
        _onAgentStarting.invoke(eventContext)
    }

    /**
     * Invoke handlers for after a node in the agent's execution graph has been processed event.
     */
    internal suspend fun invokeOnAgentCompleted(eventContext: AgentCompletedContext) {
        _onAgentCompleted.invoke(eventContext)
    }

    /**
     * Invoke handlers for an event when an error occurs during agent execution.
     */
    internal suspend fun invokeOnAgentExecutionFailed(eventContext: AgentExecutionFailedContext) {
        _onAgentExecutionFailed.invoke(eventContext)
    }

    /**
     * Invokes the handler associated with the event that occurs before an agent is closed.
     */
    internal suspend fun invokeOnAgentClosing(eventContext: AgentClosingContext) {
        _onAgentClosing.invoke(eventContext)
    }

    //endregion Invoke Agent Handlers

    //region Invoke Strategy Handlers

    /**
     * Invoke handlers for an event when strategy starts execution.
     */
    internal suspend fun invokeOnStrategyStarting(eventContext: StrategyStartingContext) {
        _onStrategyStarting.invoke(eventContext)
    }

    /**
     * Invoke handlers for an event when a strategy finishes execution.
     */
    internal suspend fun invokeOnStrategyCompleted(eventContext: StrategyCompletedContext) {
        _onStrategyCompleted.invoke(eventContext)
    }

    //endregion Invoke Strategy Handlers

    //region Invoke Node Handlers

    /**
     * Invoke handlers for before a node in the agent's execution graph is processed event.
     */
    internal suspend fun invokeOnNodeExecutionStarting(eventContext: NodeExecutionStartingContext) {
        _onNodeExecutionStarting.invoke(eventContext)
    }

    /**
     * Invoke handlers for after a node in the agent's execution graph has been processed event.
     */
    internal suspend fun invokeOnNodeExecutionCompleted(eventContext: NodeExecutionCompletedContext) {
        _onNodeExecutionCompleted.invoke(eventContext)
    }

    /**
     * Invokes the error handling logic for a node execution error event.
     */
    internal suspend fun invokeOnNodeExecutionFailed(interceptContext: NodeExecutionFailedContext) {
        _onNodeExecutionFailed.invoke(interceptContext)
    }

    //endregion Invoke Node Handlers

    //region Invoke Subgraph Handlers

    /**
     * Invoked when the execution of a subgraph is starting. This method allows
     * you to perform actions or initialize resources necessary for the subgraph
     * execution process.
     *
     * @param eventContext The context associated with the start of the subgraph
     * execution. Contains relevant details such as metadata and configuration
     * for the current subgraph execution.
     */
    internal suspend fun invokeOnSubgraphExecutionStarting(eventContext: SubgraphExecutionStartingContext) {
        _onSubgraphExecutionStarting.invoke(eventContext)
    }

    /**
     * Invoke handlers for after a subgraph in the agent's execution graph has been processed event.
     */
    internal suspend fun invokeOnSubgraphExecutionCompleted(eventContext: SubgraphExecutionCompletedContext) {
        _onSubgraphExecutionCompleted.invoke(eventContext)
    }

    /**
     * Invokes the error handling logic for a subgraph execution error event.
     */
    internal suspend fun invokeOnSubgraphExecutionFailed(interceptContext: SubgraphExecutionFailedContext) {
        _onSubgraphExecutionFailed.invoke(interceptContext)
    }

    //endregion Invoke Subgraph Handlers

    //region Invoke LLM Call Handlers

    /**
     * Invoke handlers for before a call is made to the language model event.
     */
    internal suspend fun invokeOnLLMCallStarting(eventContext: LLMCallStartingContext) {
        _onLLMCallStarting.invoke(eventContext)
    }

    /**
     * Invoke handlers for after a response is received from the language model event.
     */
    internal suspend fun invokeOnLLMCallCompleted(eventContext: LLMCallCompletedContext) {
        _onLLMCallCompleted.invoke(eventContext)
    }

    //endregion Invoke LLM Call Handlers

    //region Invoke Tool Call Handlers

    /**
     * Invoke handlers for the tool call event.
     */
    internal suspend fun invokeOnToolCallStarting(eventContext: ToolCallStartingContext) {
        _onToolCallStarting.invoke(eventContext)
    }

    /**
     * Invoke handlers for a validation error during a tool call event.
     */
    internal suspend fun invokeOnToolValidationFailed(eventContext: ToolValidationFailedContext) {
        _onToolValidationFailed.invoke(eventContext)
    }

    /**
     * Invoke handlers for a tool call failure with an exception event.
     */
    internal suspend fun invokeOnToolCallFailed(eventContext: ToolCallFailedContext) {
        _onToolCallFailed.invoke(eventContext)
    }

    /**
     * Invoke handlers for a successful tool call completion event.
     */
    internal suspend fun invokeOnToolCallCompleted(eventContext: ToolCallCompletedContext) {
        _onToolCallCompleted.invoke(eventContext)
    }

    //endregion Invoke Tool Call Handlers

    //region Invoke Stream Handlers

    /**
     * Invokes the handlers associated with the start of a language model streaming event.
     */
    internal suspend fun invokeOnLLMStreamingStarting(eventContext: LLMStreamingStartingContext) {
        _onLLMStreamingStarting.invoke(eventContext)
    }

    /**
     * Invokes the handlers associated with a received frame during language model streaming.
     */
    internal suspend fun invokeOnLLMStreamingFrameReceived(eventContext: LLMStreamingFrameReceivedContext) {
        _onLLMStreamingFrameReceived.invoke(eventContext)
    }

    /**
     * Invokes the handlers associated with a language model streaming failure event.
     */
    internal suspend fun invokeOnLLMStreamingFailed(eventContext: LLMStreamingFailedContext) {
        _onLLMStreamingFailed.invoke(eventContext)
    }

    /**
     * Invokes the handlers associated with a language model streaming completion event.
     */
    internal suspend fun invokeOnLLMStreamingCompleted(eventContext: LLMStreamingCompletedContext) {
        _onLLMStreamingCompleted.invoke(eventContext)
    }

    //endregion Invoke Stream Handlers
}
