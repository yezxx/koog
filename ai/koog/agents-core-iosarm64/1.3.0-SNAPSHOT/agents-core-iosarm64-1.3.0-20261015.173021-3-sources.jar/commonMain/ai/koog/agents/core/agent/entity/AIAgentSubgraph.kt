@file:Suppress("EXPECT_ACTUAL_CLASSIFIERS_ARE_IN_BETA_WARNING")

package ai.koog.agents.core.agent.entity

import ai.koog.agents.core.agent.context.AIAgentContext
import ai.koog.agents.core.agent.context.AIAgentGraphContextBase
import ai.koog.agents.core.agent.context.DetachedPromptExecutorAPI
import ai.koog.agents.core.agent.context.getGraphAgentContextData
import ai.koog.agents.core.agent.context.store
import ai.koog.agents.core.agent.context.with
import ai.koog.agents.core.agent.exception.AIAgentMaxNumberOfIterationsReachedException
import ai.koog.agents.core.agent.exception.AIAgentStuckInTheNodeException
import ai.koog.agents.core.agent.execution.AgentExecutionInfo
import ai.koog.agents.core.annotation.InternalAgentsApi
import ai.koog.agents.core.prompt.Prompts.selectRelevantTools
import ai.koog.agents.core.tools.ToolDescriptor
import ai.koog.agents.core.tools.annotations.LLMDescription
import ai.koog.prompt.executor.model.StructureFixingParser
import ai.koog.prompt.llm.LLModel
import ai.koog.prompt.message.Message
import ai.koog.prompt.params.LLMParams
import ai.koog.prompt.processor.ResponseProcessor
import ai.koog.prompt.structure.StructuredRequest
import ai.koog.prompt.structure.StructuredRequestConfig
import ai.koog.prompt.structure.json.JsonStructure
import ai.koog.prompt.structure.json.generator.StandardJsonSchemaGenerator
import ai.koog.serialization.TypeToken
import io.github.oshai.kotlinlogging.KotlinLogging
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.Serializable
import kotlin.uuid.ExperimentalUuidApi

/**
 * Base class for [AIAgentSubgraph].
 *
 * @param TInput The type of input data accepted by the subgraph.
 * @param TOutput The type of output data returned by the subgraph.
 * @param name The name of the subgraph.
 * @param start The starting node of the subgraph, which initiates the processing.
 * @param finish The finishing node of the subgraph, which concludes the processing.
 * @param toolSelectionStrategy Strategy determining which tools should be available during this subgraph's execution.
 * @param llmModel Optional [LLModel] override for the subgraph execution.
 * @param llmParams Optional [LLMParams] override for the prompt for the subgraph execution.
 * @param responseProcessor Optional [ResponseProcessor] override for the subgraph execution.
 * @param freshHistory When true, the subgraph starts with only the parent's system messages;
 *  user/assistant conversation turns are not inherited. The subgraph's history is discarded upon completion.
 */
public open class AIAgentSubgraphBase<TInput, TOutput>(
    override val name: String,
    public val start: StartNode<TInput>,
    public val finish: FinishNode<TOutput>,
    private val toolSelectionStrategy: ToolSelectionStrategy,
    private val llmModel: LLModel? = null,
    private val llmParams: LLMParams? = null,
    private val responseProcessor: ResponseProcessor? = null,
    private val freshHistory: Boolean = false,
) : AIAgentNodeBase<TInput, TOutput>(), ExecutionPointNode {
    override val inputType: TypeToken = start.inputType
    override val outputType: TypeToken = finish.outputType

    /**
     * Companion object for the AIAgentSubgraphBase class.
     *
     * This companion object provides predefined constants used to denote
     * special nodes (start and finish) within the subgraph of an AI agent strategy.
     * It also includes utilities for internal logging.
     */
    public companion object {
        private val logger = KotlinLogging.logger { }

        /**
         * A constant string used as a prefix to identify the starting node in an AI agent's execution graph.
         * This prefix is used to ensure unique identification and separation of the start node
         * within the graph structure or during execution-related operations.
         */
        public const val START_NODE_PREFIX: String = "__start__"

        /**
         * A constant string used as a prefix to identify "finish" nodes within the AI agent subgraph.
         * Finish nodes typically signify the conclusion of a sequence or process in the graph,
         * and this prefix is used to mark such nodes for easier recognition and handling.
         */
        public const val FINISH_NODE_PREFIX: String = "__finish__"
    }

    private var forcedNode: AIAgentNodeBase<*, *>? = null
    private var forcedInput: Any? = null

    override fun getExecutionPoint(): ExecutionPoint? {
        val forcedNode = this.forcedNode
        return if (forcedNode != null) {
            ExecutionPoint(forcedNode, forcedInput)
        } else {
            null
        }
    }

    override fun resetExecutionPoint() {
        forcedNode = null
        forcedInput = null
    }

    override fun enforceExecutionPoint(
        node: AIAgentNodeBase<*, *>,
        input: Any?
    ) {
        if (forcedNode != null || forcedInput != null) {
            throw IllegalStateException("Forced node is already set to ${forcedNode!!.name}")
        }
        forcedNode = node
        forcedInput = input
    }

    @Serializable
    private data class SelectedTools(
        @property:LLMDescription("List of selected tools for the given subtask")
        val tools: List<String>
    )

    @OptIn(DetachedPromptExecutorAPI::class)
    private suspend fun selectTools(context: AIAgentContext) = when (toolSelectionStrategy) {
        is ToolSelectionStrategy.ALL -> context.llm.tools
        is ToolSelectionStrategy.NONE -> emptyList()
        is ToolSelectionStrategy.Tools -> toolSelectionStrategy.tools
        is ToolSelectionStrategy.AutoSelectForTask -> context.llm.writeSession {
            val initialPrompt = prompt

            replaceHistoryWithTLDR()

            appendPrompt {
                user {
                    selectRelevantTools(tools, toolSelectionStrategy.subtaskDescription)
                }
            }

            val selectedTools = this.requestLLMStructured(
                config = StructuredRequestConfig(
                    default = StructuredRequest.Manual(
                        JsonStructure.create<SelectedTools>(
                            schemaGenerator = StandardJsonSchemaGenerator,
                            examples = listOf(SelectedTools(listOf()), SelectedTools(tools.map { it.name }.take(3))),
                        ),
                    ),
                ),
                fixingParser = toolSelectionStrategy.fixingParser,
            ).getOrThrow()

            prompt = initialPrompt

            tools.filter { it.name in selectedTools.data.tools.toSet() }
        }
    }

    /**
     * Executes the subgraph for the given [input] within [context].
     *
     * During execution this method:
     * - Resolves the effective toolset according to the configured [ToolSelectionStrategy] and replaces
     *   [context]'s LLM context with an updated one, overriding `tools`, and optionally `model`,
     *   `prompt.params` and `responseProcessor` for the duration of the subgraph execution.
     * - Emits `onSubgraphExecutionStarting`, `onSubgraphExecutionCompleted` and `onSubgraphExecutionFailed`
     *   pipeline events, unless this subgraph is the strategy-level subgraph (which is reported separately).
     * - Runs nodes starting from [start] (or from an enforced [ExecutionPoint], if present) and follows
     *   edges until [finish] is reached or execution is interrupted.
     * - Restores the original LLM context afterwards, preserving the updated message history.
     *
     * @param context The graph execution context which includes all necessary resources and metadata for execution.
     * @param input The input data to be processed by the subgraph.
     * @return The output produced by [finish], or `null` if execution was interrupted
     * (for example, due to a requested jump to another node or a checkpoint rollback).
     */
    @OptIn(InternalAgentsApi::class, DetachedPromptExecutorAPI::class, ExperimentalUuidApi::class)
    override suspend fun execute(context: AIAgentGraphContextBase, input: TInput): TOutput? =
        context.with { executionInfo, eventId ->
            val newTools = selectTools(context)

            // Copy inner context with new tools, model and LLM params.
            val initialLLMContext = context.llm

            val effectiveParams = llmParams ?: context.llm.prompt.params
            val innerPrompt = context.llm.prompt.copy(
                messages = if (freshHistory) {
                    context.llm.prompt.messages.filterIsInstance<Message.System>()
                } else {
                    context.llm.prompt.messages
                },
                params = effectiveParams,
            )

            context.replace(
                context.copy(
                    llm = context.llm.copy(
                        tools = newTools,
                        model = llmModel ?: context.llm.model,
                        prompt = innerPrompt,
                        responseProcessor = responseProcessor ?: context.llm.responseProcessor,
                    ),
                ),
            )

            runIfNotStrategy(context) {
                pipeline.onSubgraphExecutionStarting(
                    eventId,
                    executionInfo,
                    context,
                    this@AIAgentSubgraphBase,
                    input,
                    inputType
                )
            }

            // Execute the subgraph with an inner context and get the result and updated prompt.
            val result = try {
                executeWithInnerContext(context, input)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                logger.error(e) { "Exception during executing subgraph '$name': ${e.message}" }
                runIfNotStrategy(context) {
                    pipeline.onSubgraphExecutionFailed(
                        eventId,
                        executionInfo,
                        context,
                        this@AIAgentSubgraphBase,
                        input,
                        inputType,
                        e
                    )
                }
                throw e
            }

            // Restore original LLM context. When freshHistory is enabled, the subgraph's
            // conversation is self-contained — discard it and restore the original prompt.
            val restoredPrompt = if (freshHistory) {
                initialLLMContext.prompt
            } else {
                context.llm.prompt.copy(params = initialLLMContext.prompt.params)
            }

            context.replace(
                context.copy(
                    llm = initialLLMContext.copy(prompt = restoredPrompt),
                ),
            )

            val innerForcedData = context.getGraphAgentContextData()

            if (innerForcedData != null) {
                context.store(innerForcedData)
            }

            runIfNotStrategy(context) {
                pipeline.onSubgraphExecutionCompleted(
                    eventId,
                    executionInfo,
                    context,
                    this@AIAgentSubgraphBase,
                    input,
                    inputType,
                    result,
                    outputType
                )
            }

            result
        }

    @OptIn(InternalAgentsApi::class)
    private suspend fun executeWithInnerContext(context: AIAgentGraphContextBase, initialInput: TInput): TOutput? {
        logger.debug { formatLog(context, "Executing subgraph '$name'") }

        var currentNode: AIAgentNodeBase<*, *> = start
        var currentInput: Any? = initialInput

        val executionPoint = getExecutionPoint()
        if (executionPoint != null) {
            currentNode = executionPoint.node
            currentInput = executionPoint.input

            logger.info { formatLog(context, "Enforcing execution point: ${currentNode.name}") }

            resetExecutionPoint()
        } else {
            logger.info { formatLog(context, "No enforced execution point, starting from ${currentNode.name}") }
        }

        while (true) {
            context.stateManager.withStateLock { state ->
                if (++state.iterations > context.config.maxAgentIterations) {
                    logger.error {
                        formatLog(
                            context,
                            "Max iterations limit (${context.config.maxAgentIterations}) reached"
                        )
                    }
                    throw AIAgentMaxNumberOfIterationsReachedException(context.config.maxAgentIterations)
                }
            }

            // run the current node and get its output
            logger.debug { formatLog(context, "Executing node '${currentNode.name}'") }
            val nodeOutput: Any? = currentNode.executeUnsafe(context, currentInput)
            logger.debug { formatLog(context, "Completed node '${currentNode.name}'") }

            // forced context data means that we've requested interruption due to jump to another node / rolling back to checkpoint
            if (context.getGraphAgentContextData() != null) {
                return null
            }

            // find the suitable edge to move to the next node, get the transformed output
            val resolvedEdge = currentNode.resolveEdgeUnsafe(context, nodeOutput)

            // In we are in the finish node, we need to exit, otherwise we stuck in the node
            if (resolvedEdge == null) {
                if (currentNode == finish) {
                    currentInput = nodeOutput
                    break
                } else {
                    logger.error { formatLog(context, "Agent stuck in node ${currentNode.name}") }
                    throw AIAgentStuckInTheNodeException(currentNode, nodeOutput)
                }
            }

            currentNode = resolvedEdge.edge.toNode
            currentInput = resolvedEdge.output
        }

        logger.debug { formatLog(context, "Completed subgraph $name") }
        @Suppress("UNCHECKED_CAST")
        val result = (currentInput as? TOutput) ?: run {
            logger.error {
                formatLog(
                    context,
                    "Invalid finish node output type: ${currentInput?.let { it::class.simpleName }}"
                )
            }
            throw IllegalStateException("${FinishNode::class.simpleName} should always return a value assignable to the declared output type")
        }
        return result
    }

    /**
     * Executes the specified action only when running subgraph logic, and not when the current
     * subgraph is the strategy-level subgraph.
     *
     * A strategy is a special case of subgraph execution. Strategy execution wraps the subgraph [execute] method
     * with its specific implementation. This method ensures that the action we run is only
     * executed if the current subgraph is not a strategy.
     *
     * The method is used for reporting subgraph-only agent events in the [ai.koog.agents.core.feature.pipeline.AIAgentPipeline].
     */
    @OptIn(InternalAgentsApi::class)
    private inline fun runIfNotStrategy(
        context: AIAgentGraphContextBase,
        action: AIAgentGraphContextBase.() -> Unit
    ) {
        // Check the agent execution path to recognize a strategy.
        // Ignore the strategy as it is handled separately in the [AIAgentGraphStrategy] class.
        // Strategy execution path: Agent | Run | Strategy
        val isStrategy = id == context.strategyName

        if (isStrategy) {
            return
        }

        action(context)
    }

    /**
     * Use this special wrapper to execute a block of code with a modified execution context for cases when
     * performing a direct subgraph execution.
     *
     * A strategy is a special case of subgraph execution. Strategy execution wraps the subgraph [execute] method
     * with its specific implementation. This wrapper ensures that for non-strategy subgraphs the block is
     * executed with an execution scope keyed by the subgraph [id], while for strategy subgraphs the existing
     * execution info from the context is reused.
     */
    @OptIn(InternalAgentsApi::class)
    private inline fun <T> AIAgentContext.with(
        block: (executionInfo: AgentExecutionInfo, eventId: String) -> T
    ): T {
        // Check the agent execution path to recognize a strategy.
        // Ignore the strategy as it is handled separately in the [AIAgentGraphStrategy] class.
        // Strategy execution path: Agent | Run | Strategy
        val isStrategy = id == strategyName
        return if (isStrategy) {
            this.with(this.executionInfo, block)
        } else {
            this.with(id, block)
        }
    }

    private fun formatLog(context: AIAgentContext, message: String): String =
        "$message [$name, ${context.strategyName}, ${context.runId}]"
}

/**
 * Represents a subgraph within an AI agent execution strategy capable of processing input and producing output.
 *
 * A subgraph is a modular component of a larger execution graph, defined by a [StartNode] as the entry point
 * and a [FinishNode] as the exit point. The subgraph may implement tool selection strategies, incorporate language
 * model support, and apply custom response processing to tailor its behavior within the broader agent workflow.
 *
 * @param TInput The type of input data accepted by the subgraph.
 * @param TOutput The type of output data returned by the subgraph.
 * @param name The name of the subgraph.
 * @param start The starting node of the subgraph, which initiates the processing.
 * @param finish The finishing node of the subgraph, which concludes the processing.
 * @param toolSelectionStrategy Strategy determining which tools should be available during this subgraph's execution.
 * @param llmModel Optional [LLModel] override for the subgraph execution.
 * @param llmParams Optional [LLMParams] override for the prompt for the subgraph execution.
 * @param responseProcessor Optional [ResponseProcessor] override for the subgraph execution.
 */
public expect class AIAgentSubgraph<TInput, TOutput> constructor(
    name: String,
    start: StartNode<TInput>,
    finish: FinishNode<TOutput>,
    toolSelectionStrategy: ToolSelectionStrategy,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    responseProcessor: ResponseProcessor? = null,
    freshHistory: Boolean = false,
) : AIAgentSubgraphBase<TInput, TOutput>

/**
 * Represents a strategy to select a subset of tools to be used in a subgraph during its execution.
 *
 * This interface provides different configurations for tool selection, ranging from using all
 * available tools to a specific subset determined by the context or explicitly provided.
 */
public sealed interface ToolSelectionStrategy {
    /**
     * Represents the inclusion of all available tools in a given subgraph or process.
     *
     * This object signifies that no filtering or selection is applied to the set of tools
     * being used, and every tool is considered relevant for execution.
     *
     * Used in contexts where all tools should be provided or included without constraint,
     * such as within a `AIAgentSubgraph` or similar constructs.
     */
    public data object ALL : ToolSelectionStrategy

    /**
     * Represents a specific subset of tools used within a subgraph configuration where no tools are selected.
     *
     * This object, when used, implies that the subgraph should operate without any tools available. It can be
     * used in scenarios where tool functionality is not required or should be explicitly restricted.
     *
     * Part of the sealed interface [ToolSelectionStrategy] which defines various tool subset configurations
     * for subgraph behaviors.
     */
    public data object NONE : ToolSelectionStrategy

    /**
     * Represents a subset of tools tailored to the specific requirements of a subtask.
     *
     * The purpose of this class is to dynamically select and include only the tools that are directly relevant
     * to the provided subtask description by asking the LLM, using a structured request, which tools from the
     * currently available toolset are relevant to [subtaskDescription]. This ensures that unnecessary tools
     * are excluded, optimizing the toolset for the specific use case.
     *
     * @property subtaskDescription A description of the subtask for which the relevant tools should be selected.
     * @property fixingParser Optional [StructureFixingParser] to attempt fixes when a malformed structured response with a tool list is received.
     */
    public data class AutoSelectForTask(
        val subtaskDescription: String,
        val fixingParser: StructureFixingParser? = null
    ) : ToolSelectionStrategy

    /**
     * Represents a subset of tools to be used within a subgraph or task.
     *
     * The Tools class allows for specifying a custom selection of tools that are relevant
     * to a specific operation or task. It forms a part of the [ToolSelectionStrategy] interface
     * hierarchy for flexible and dynamic tool configurations.
     *
     * @property tools A collection of `ToolDescriptor` objects defining the tools to be used.
     */
    public data class Tools(val tools: List<ToolDescriptor>) : ToolSelectionStrategy
}
