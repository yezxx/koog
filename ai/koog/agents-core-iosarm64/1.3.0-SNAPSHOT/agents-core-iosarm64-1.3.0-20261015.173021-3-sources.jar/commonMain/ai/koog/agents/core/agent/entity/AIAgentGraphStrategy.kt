@file:Suppress("EXPECT_ACTUAL_CLASSIFIERS_ARE_IN_BETA_WARNING")

package ai.koog.agents.core.agent.entity

import ai.koog.agents.core.agent.context.AIAgentContext
import ai.koog.agents.core.agent.context.AIAgentGraphContextBase
import ai.koog.agents.core.agent.context.GraphAgentContextData
import ai.koog.agents.core.agent.context.getGraphAgentContextData
import ai.koog.agents.core.agent.context.removeGraphAgentContextData
import ai.koog.agents.core.agent.execution.DEFAULT_AGENT_PATH_SEPARATOR
import ai.koog.agents.core.annotation.InternalAgentsApi
import ai.koog.serialization.JSONElement
import ai.koog.serialization.JSONNull
import io.github.oshai.kotlinlogging.KotlinLogging
import kotlinx.serialization.json.Json

/**
 * Represents a strategy for managing and executing AI agent workflows built as subgraphs of interconnected nodes.
 *
 * @property name The unique identifier for the strategy.
 * @property nodeStart The starting node of the strategy, initiating the subgraph execution.
 * By default, the start node receives the agent input and passes it through unchanged to the next node.
 * @property nodeFinish The finishing node of the strategy, marking the subgraph's endpoint.
 * @property toolSelectionStrategy The strategy responsible for determining the toolset available during subgraph execution.
 */
public expect class AIAgentGraphStrategy<TInput, TOutput>(
    name: String,
    nodeStart: StartNode<TInput>,
    nodeFinish: FinishNode<TOutput>,
    toolSelectionStrategy: ToolSelectionStrategy,
    serializer: Json = Json { prettyPrint = true }
) : AIAgentGraphStrategyBase<TInput, TOutput>

/**
 * Base class for [AIAgentGraphStrategy].
 *
 * @property name The unique identifier for the strategy.
 * @property nodeStart The starting node of the strategy, initiating the subgraph execution.
 * By default, the start node receives the agent input and passes it through unchanged to the next node.
 * @property nodeFinish The finishing node of the strategy, marking the subgraph's endpoint.
 * @property toolSelectionStrategy The strategy responsible for determining the toolset available during subgraph execution.
 */
public open class AIAgentGraphStrategyBase<TInput, TOutput>(
    override val name: String,
    public val nodeStart: StartNode<TInput>,
    public val nodeFinish: FinishNode<TOutput>,
    toolSelectionStrategy: ToolSelectionStrategy,
    private val serializer: Json = Json { prettyPrint = true }
) : AIAgentStrategy<TInput, TOutput, AIAgentGraphContextBase>, AIAgentSubgraphBase<TInput, TOutput>(
    name,
    nodeStart,
    nodeFinish,
    toolSelectionStrategy
) {

    private companion object {
        private val logger = KotlinLogging.logger { }
    }

    /**
     * Represents the metadata of the subgraph associated with the AI agent strategy.
     *
     * This variable holds essential information about the structure and properties of the
     * subgraph, such as the mapping of node names to their associated implementations and
     * the uniqueness of node names within the subgraph.
     *
     * The property is a [lateinit] var that is expected to be assigned once by the graph builder
     * after the strategy has been constructed. Accessing it before it has been initialized will
     * result in an [UninitializedPropertyAccessException].
     */
    public lateinit var metadata: SubgraphMetadata

    @OptIn(InternalAgentsApi::class)
    override suspend fun execute(context: AIAgentGraphContextBase, input: TInput): TOutput? {
        restoreStateIfNeeded(context)

        var result: TOutput? = super.execute(context = context, input = input)

        while (result == null && context.getGraphAgentContextData() != null) {
            restoreStateIfNeeded(context)
            result = super.execute(context = context, input = input)
        }

        return result
    }

    @OptIn(InternalAgentsApi::class)
    private suspend fun restoreStateIfNeeded(
        agentContext: AIAgentGraphContextBase
    ) {
        val additionalContextData: GraphAgentContextData = agentContext.getGraphAgentContextData() ?: return

        restoreDefault(agentContext, additionalContextData)
        agentContext.removeGraphAgentContextData()
    }

    @OptIn(InternalAgentsApi::class)
    private suspend fun restoreMessageOnly(agentContext: AIAgentContext, data: GraphAgentContextData) {
        agentContext.llm.withPrompt {
            this.withMessages { (data.messageHistory) }
        }
    }

    @OptIn(InternalAgentsApi::class)
    private suspend fun restoreDefault(agentContext: AIAgentGraphContextBase, data: GraphAgentContextData) {
        val nodePath = data.nodePath

        // Perform additional cleanup (ex: rollback tools):
        data.additionalRollbackActions(agentContext)

        // Set current graph node:
        if (data.lastOutput != JSONNull) {
            setExecutionPointAfterNode(nodePath, data.lastOutput, agentContext)
        } else {
            logger.warn { "Unexpected state in checkpoint: output was not saved" }
        }

        // Restore LLM session
        agentContext.llm.writeSession {
            // Restore LLM model
            data.llmModel?.let { model = it }

            // Restore messages and LLM params
            prompt = prompt.copy(
                messages = data.messageHistory,
                params = data.llmParams ?: prompt.params
            )

            data.tools?.let { toolNames ->
                // Restore tools
                tools = tools.filter { it.name in toolNames }
            }
        }

        // Restore the storage
        agentContext.storage.putAllSerialized(data.storage.entries)

        // Restore agent iterations
        agentContext.stateManager.withStateLock { state ->
            state.iterations = data.agentIterations
        }
    }

    private fun setExecutionPointImpl(pathSegments: List<String>, node: AIAgentNodeBase<*, *>, input: Any?) {
        val strategyName = pathSegments.firstOrNull() ?: return

        // getting the very first segment (it should be a root strategy node)
        var currentNode: AIAgentNodeBase<*, *>? = metadata.nodesMap[strategyName]
        var currentPath = strategyName

        // restoring the current node for each subgraph including strategy
        val segmentsInbetween = pathSegments.drop(1).dropLast(1)
        for (segment in segmentsInbetween) {
            val currNode = currentNode as? ExecutionPointNode
                ?: throw IllegalStateException(
                    "Restore for path " +
                        "${pathSegments.joinToString(DEFAULT_AGENT_PATH_SEPARATOR)} failed: " +
                        "one of middle segments is not a subgraph"
                )

            currentPath = "$currentPath${DEFAULT_AGENT_PATH_SEPARATOR}$segment"
            val nextNode = metadata.nodesMap[currentPath]
            if (nextNode is ExecutionPointNode) {
                currNode.enforceExecutionPoint(nextNode, input)
                currentNode = nextNode
            }
        }

        val leaf = node
        node.let {
            currentNode as? ExecutionPointNode
                ?: throw IllegalStateException("Node ${currentNode?.name} is not a valid leaf node")
            currentNode.enforceExecutionPoint(it, input)
        }
    }

    /**
     * Enforces the strategy's next execution to continue right after the node identified by [nodePath],
     * using [output] as that node's completed output.
     *
     * [nodePath] is a [DEFAULT_AGENT_PATH_SEPARATOR]-joined path whose first segment is the agent's id
     * and is ignored; the remaining segments identify the completed node inside this strategy's [metadata].
     * [output] is decoded using the completed node's [AIAgentNodeBase.outputType].
     *
     * Behavior:
     * - If the completed node is a [FinishNode], the subgraph containing it is resumed by re-starting the
     *   finish node with [output] (finish nodes have no outgoing edges and input equals output).
     * - Otherwise, the outgoing edge of the completed node is resolved against [output] and the resulting
     *   next node and transformed input are set as the new execution point.
     *
     * @param nodePath The path identifying the completed node within the strategy's metadata.
     * @param output The serialized output produced by the node at [nodePath].
     * @param agentContext The graph context whose execution point should be enforced.
     * @throws IllegalArgumentException if [nodePath] does not contain any node segment after the agent id.
     * @throws IllegalStateException if no node corresponding to [nodePath] can be found in [metadata],
     * if no outgoing edge matches the produced output, or if one of the intermediate path segments is not
     * an [ExecutionPointNode].
     */
    public suspend fun setExecutionPointAfterNode(
        nodePath: String,
        output: JSONElement,
        agentContext: AIAgentGraphContextBase
    ) {
        // we drop first because it's agent's id, we don't need it here
        val segments = nodePath.split(DEFAULT_AGENT_PATH_SEPARATOR).drop(1)

        if (segments.isEmpty()) {
            throw IllegalArgumentException("Invalid node path: $nodePath")
        }

        val actualPath = segments.joinToString(DEFAULT_AGENT_PATH_SEPARATOR)

        val completedNode = metadata.nodesMap[actualPath] ?: throw IllegalStateException("Node $actualPath not found")

        val actualOutput = agentContext.config.serializer
            .decodeFromJSONElement<Any?>(output, completedNode.outputType)

        if (completedNode is FinishNode<*>) {
            // finish node (of some subgraph) doesn't have next edges, and it's input equals output, so it's safe to re-start it:
            setExecutionPointImpl(
                pathSegments = segments,
                node = completedNode,
                input = actualOutput
            )
        } else {
            val resolvedEdge = completedNode.resolveEdgeUnsafe(agentContext, actualOutput)
            val nextNode = resolvedEdge?.edge?.toNode ?: throw IllegalStateException("Node $nodePath not found")
            val nextNodeInput = resolvedEdge.output

            setExecutionPointImpl(
                pathSegments = segments.dropLast(1) + nextNode.name,
                node = nextNode,
                input = nextNodeInput
            )
        }
    }
}
