package ai.koog.agents.core.agent

import ai.koog.agents.core.agent.AIAgentTool.AgentToolInput
import ai.koog.agents.core.agent.AIAgentTool.AgentToolResult
import ai.koog.agents.core.tools.Tool
import ai.koog.agents.core.tools.ToolDescriptor
import ai.koog.agents.core.tools.ToolParameterDescriptor
import ai.koog.agents.core.tools.annotations.InternalAgentToolsApi
import ai.koog.agents.core.tools.schema.getJsonSchema
import ai.koog.agents.core.tools.schema.toToolParameter
import ai.koog.serialization.JSONElement
import ai.koog.serialization.JSONSerializer
import ai.koog.serialization.TypeToken
import ai.koog.serialization.annotations.InternalKoogSerializationApi
import ai.koog.serialization.kotlinx.KotlinxDelegateSerializer
import ai.koog.serialization.kotlinx.toKoogJSONElement
import ai.koog.serialization.kotlinx.toKotlinxJsonElement
import ai.koog.serialization.typeToken
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.concurrent.atomics.AtomicInt
import kotlin.concurrent.atomics.ExperimentalAtomicApi
import kotlin.concurrent.atomics.fetchAndIncrement
import kotlin.coroutines.cancellation.CancellationException

/**
 * AIAgentTool is a generic tool that wraps an AI agent to facilitate integration
 * with the context of a tool execution framework. It enables the serialization,
 * deserialization, and execution of an AI agent's operations.
 *
 * @param Input The type of input expected by the AI agent.
 * @param Output The type of output produced by the AI agent.
 * @param agentService The AI agent service to create the agent.
 * @param agentName A unique name for the agent.
 * @param agentDescription A brief description of the agent's functionality.
 * If not specified for a primitive input type (ex: String, Int, ...), an empty input description will be sent to LLM.
 * Does not have any effect for non-primitive [Input] type with @LLMDescription annotations.
 * @param inputType Type token representing input type.
 * @param outputType Type token representing output type.
 * @param parentAgentId Optional ID of the parent AI agent. Tool agent IDs will be generated as "parentAgentId.<number of tool call>"
 */
public class AIAgentTool<Input, Output> @OptIn(InternalAgentToolsApi::class) constructor(
    private val agentService: AIAgentService<Input, Output, *>,
    private val agentName: String,
    private val agentDescription: String,
    private val inputDescription: String? = null,
    private val inputType: TypeToken,
    private val outputType: TypeToken,
    private val parentAgentId: String? = null
) : Tool<AgentToolInput<Input>, AgentToolResult<Output>>(
    argsType = typeToken(AgentToolInput::class, listOf(inputType)),
    resultType = typeToken(AgentToolResult::class, listOf(outputType)),
    descriptor = run {
        val inputSchema = getJsonSchema(inputType)
        val inputToolParameter = inputSchema.toToolParameter(inputSchema.defs)

        ToolDescriptor(
            name = agentName,
            description = agentDescription,
            requiredParameters = listOf(
                ToolParameterDescriptor(
                    name = "input",
                    description = inputDescription ?: "input",
                    type = inputToolParameter.type,
                )
            )
        )
    }
) {
    private companion object {
        private val json = Json.Default
    }

    @OptIn(ExperimentalAtomicApi::class)
    private val toolCallNumber: AtomicInt = AtomicInt(0)

    @OptIn(ExperimentalAtomicApi::class)
    private fun nextToolAgentID(): String = "$parentAgentId.${toolCallNumber.fetchAndIncrement()}"

    /**
     * Represents the result of executing an agent tool operation.
     *
     * @property successful Indicates whether the operation was successful.
     * @property errorMessage An optional error message describing the failure, if any.
     * @property result An optional agent tool result.
     */
    @Serializable
    public data class AgentToolResult<Output>(
        val successful: Boolean,
        val errorMessage: String? = null,
        val result: Output? = null
    )

    /**
     * Represents the input for [AIAgent] used as [Tool] (see [AIAgent.asTool])
     *
     * @param Input The type of the input data expected by the tool.
     * @property input The input data provided to the agent tool for processing.
     */
    @Serializable
    public data class AgentToolInput<Input>(
        val input: Input
    )

    @OptIn(InternalKoogSerializationApi::class)
    override fun decodeResult(rawResult: JSONElement, serializer: JSONSerializer): AgentToolResult<Output> {
        return json.decodeFromJsonElement(
            deserializer = AgentToolResult.serializer(
                KotlinxDelegateSerializer(serializer, outputType)
            ),
            element = rawResult.toKotlinxJsonElement(),
        )
    }

    @OptIn(InternalKoogSerializationApi::class)
    override fun encodeResult(result: AgentToolResult<Output>, serializer: JSONSerializer): JSONElement {
        return json.encodeToJsonElement(
            serializer = AgentToolResult.serializer(
                KotlinxDelegateSerializer(serializer, outputType)
            ),
            value = result,
        ).toKoogJSONElement()
    }

    @OptIn(InternalAgentToolsApi::class)
    override suspend fun execute(args: AgentToolInput<Input>): AgentToolResult<Output> {
        val input = args.input

        return try {
            val result = agentService.createAgentAndRun(input, id = nextToolAgentID())

            AgentToolResult(
                successful = true,
                result = result,
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AgentToolResult(
                successful = false,
                errorMessage = "Error happened: ${e::class.simpleName}(${e.message})\n${e.stackTraceToString().take(100)}"
            )
        }
    }
}
