package ai.koog.agents.core.feature.handler.subgraph

import ai.koog.agents.core.agent.context.AIAgentContext
import ai.koog.agents.core.agent.entity.AIAgentSubgraphBase
import ai.koog.agents.core.agent.execution.AgentExecutionInfo
import ai.koog.agents.core.feature.handler.AgentLifecycleEventContext
import ai.koog.agents.core.feature.handler.AgentLifecycleEventType
import ai.koog.serialization.TypeToken

/**
 * Represents the context for handling subgraph-specific events for graph strategies within the framework.
 */
public interface SubgraphExecutionEventContext : AgentLifecycleEventContext {
    /**
     * The context in which the subgraph is being executed.
     */
    public val context: AIAgentContext

    /**
     * The subgraph instance that is being executed.
     */
    public val subgraph: AIAgentSubgraphBase<*, *>
}

/**
 * The context for handling a subgraph execution starting event.
 *
 * @property input The input data for the subgraph execution.
 * @property inputType The type of the input data for the subgraph execution.
 */
public data class SubgraphExecutionStartingContext(
    override val eventId: String,
    override val executionInfo: AgentExecutionInfo,
    override val context: AIAgentContext,
    override val subgraph: AIAgentSubgraphBase<*, *>,
    public val input: Any?,
    public val inputType: TypeToken,
) : SubgraphExecutionEventContext {
    override val eventType: AgentLifecycleEventType = AgentLifecycleEventType.SubgraphExecutionStarting
}

/**
 * The context for handling a subgraph execution completed event.
 *
 * @property input The input data for the subgraph execution.
 * @property inputType The type of the input data for the subgraph execution.
 * @property output The output data from the subgraph execution.
 * @property outputType The type of the output data for the subgraph execution.
 */
public data class SubgraphExecutionCompletedContext(
    override val eventId: String,
    override val executionInfo: AgentExecutionInfo,
    override val context: AIAgentContext,
    override val subgraph: AIAgentSubgraphBase<*, *>,
    public val input: Any?,
    public val inputType: TypeToken,
    val output: Any?,
    val outputType: TypeToken,
) : SubgraphExecutionEventContext {
    override val eventType: AgentLifecycleEventType = AgentLifecycleEventType.SubgraphExecutionCompleted
}

/**
 * The context for handling a subgraph execution failed event.
 *
 * @property input The input data for the subgraph execution.
 * @property inputType The type of the input data for the subgraph execution.
 * @property error The exception that caused the subgraph execution to fail.
 */
public data class SubgraphExecutionFailedContext(
    override val eventId: String,
    override val executionInfo: AgentExecutionInfo,
    override val context: AIAgentContext,
    override val subgraph: AIAgentSubgraphBase<*, *>,
    public val input: Any?,
    public val inputType: TypeToken,
    public val error: Throwable
) : SubgraphExecutionEventContext {
    override val eventType: AgentLifecycleEventType = AgentLifecycleEventType.SubgraphExecutionFailed
}
