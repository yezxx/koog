package ai.koog.agents.core.agent.context

import ai.koog.agents.core.agent.config.AIAgentConfig
import ai.koog.agents.core.agent.entity.AIAgentStateManager
import ai.koog.agents.core.agent.entity.AIAgentStorage
import ai.koog.agents.core.agent.execution.AgentExecutionInfo
import ai.koog.agents.core.environment.AIAgentEnvironment
import ai.koog.agents.core.feature.pipeline.AIAgentFunctionalPipeline

/**
 * Represents the context for an AI agent of FunctionalAIAgent type,
 * serving as the execution environment and state holder
 * while an agent operates within a predefined pipeline. It extends [AIAgentFunctionalContextBase] and is
 * designed to allow configuration, state management, and storage for an agent's functional operations.
 *
 * @param environment The [AIAgentEnvironment] in which the AI agent operates, facilitating interaction
 *        with the external environment for tool execution and error reporting.
 * @param agentId A unique identifier for the agent, used to distinguish it from other agents.
 * @param runId An identifier representing the execution run of the agent, useful for tracking and managing runs.
 * @param agentInput The input data provided to the agent, which can guide its execution or decision-making process.
 * @param config The [AIAgentConfig] object containing configuration information for the agent, such as behavior settings.
 * @param llm The [AIAgentLLMContext] providing access to the large language model interactions for generating outputs.
 * @param stateManager The [AIAgentStateManager] responsible for managing and persisting the state of the agent during its lifecycle.
 * @param storage The [AIAgentStorage] interface facilitating storage and retrieval of data in the agent's environment.
 * @param strategyName The name of the strategic approach or plan under which the agent is functioning.
 * @param pipeline The [AIAgentFunctionalPipeline] defining the functional execution flow of the agent's operations.
 * @param executionInfo The [AgentExecutionInfo] containing metadata and runtime information about the agent's current execution.
 * @param parentContext An optional reference to the parent [AIAgentContext], enabling hierarchical context structure if needed.
 */
public class AIAgentFunctionalContext(
    environment: AIAgentEnvironment,
    agentId: String,
    runId: String,
    agentInput: Any?,
    config: AIAgentConfig,
    llm: AIAgentLLMContext,
    stateManager: AIAgentStateManager,
    storage: AIAgentStorage,
    strategyName: String,
    pipeline: AIAgentFunctionalPipeline,
    executionInfo: AgentExecutionInfo,
    parentContext: AIAgentContext? = null
) : AIAgentFunctionalContextBase<AIAgentFunctionalPipeline>(
    environment = environment,
    agentId = agentId,
    runId = runId,
    agentInput = agentInput,
    config = config,
    llm = llm,
    stateManager = stateManager,
    storage = storage,
    strategyName = strategyName,
    pipeline = pipeline,
    executionInfo = executionInfo,
    parentContext = parentContext
) {

    /**
     * Creates a copy of the current [AIAgentFunctionalContext], allowing for selective overriding of its properties.
     * This method is useful for creating modified contexts during agent execution without mutating the original context.
     *
     * @param environment The [AIAgentEnvironment] to be used in the new context, or the current one if not specified.
     * @param agentId The unique agent identifier, or the current one if not specified.
     * @param runId The run identifier, or the current run ID if not specified.
     * @param agentInput The input data for the agent, or the current input if not specified.
     * @param config The [AIAgentConfig] for the new context, or the current configuration if not specified.
     * @param llm The [AIAgentLLMContext] to be used, or the current LLM context if not specified.
     * @param stateManager The [AIAgentStateManager] to be used, or the current state manager if not specified.
     * @param storage The [AIAgentStorage] to be used, or the current storage if not specified.
     * @param strategyName The strategy name, or the current strategy name if not specified.
     * @param pipeline The [AIAgentFunctionalPipeline] to be used, or the current pipeline if not specified.
     * @param executionInfo The [AgentExecutionInfo] to be used, or the current execution info if not specified.
     * @param parentRootContext The parent context, or the current parent context if not specified.
     * @return A new [AIAgentFunctionalContext] with the specified modifications applied.
     */
    public fun copy(
        environment: AIAgentEnvironment = this.environment,
        agentId: String = this.agentId,
        runId: String = this.runId,
        agentInput: Any? = this.agentInput,
        config: AIAgentConfig = this.config,
        llm: AIAgentLLMContext = this.llm,
        stateManager: AIAgentStateManager = this.stateManager,
        storage: AIAgentStorage = this.storage,
        strategyName: String = this.strategyName,
        pipeline: AIAgentFunctionalPipeline = this.pipeline,
        executionInfo: AgentExecutionInfo = this.executionInfo,
        parentRootContext: AIAgentContext? = this.parentContext,
    ): AIAgentFunctionalContext = AIAgentFunctionalContext(
        environment = environment,
        agentId = agentId,
        runId = runId,
        agentInput = agentInput,
        config = config,
        llm = llm,
        stateManager = stateManager,
        storage = storage,
        strategyName = strategyName,
        pipeline = pipeline,
        executionInfo = executionInfo,
        parentContext = parentRootContext
    )
}
