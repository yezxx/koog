package ai.koog.agents.core.feature.pipeline

import ai.koog.agents.core.agent.context.AIAgentGraphContextBase
import ai.koog.agents.core.agent.entity.AIAgentNodeBase
import ai.koog.agents.core.agent.entity.AIAgentSubgraphBase
import ai.koog.agents.core.agent.execution.AgentExecutionInfo
import ai.koog.agents.core.annotation.InternalAgentsApi
import ai.koog.agents.core.feature.AIAgentGraphFeature
import ai.koog.agents.core.feature.handler.node.NodeExecutionCompletedContext
import ai.koog.agents.core.feature.handler.node.NodeExecutionFailedContext
import ai.koog.agents.core.feature.handler.node.NodeExecutionStartingContext
import ai.koog.agents.core.feature.handler.subgraph.SubgraphExecutionCompletedContext
import ai.koog.agents.core.feature.handler.subgraph.SubgraphExecutionFailedContext
import ai.koog.agents.core.feature.handler.subgraph.SubgraphExecutionStartingContext
import ai.koog.serialization.TypeToken
import kotlin.jvm.JvmSynthetic

/**
 * Public API surface for graph-specific pipeline operations (nodes and subgraphs).
 *
 * Implemented by both the common expect AIAgentGraphPipeline and the concrete implementation
 * AIAgentGraphPipelineImpl, and used by all platform actual classes via delegation.
 */
public interface AIAgentGraphPipelineAPI : AIAgentPipelineAPI {

    //region Trigger Node Handlers

    @InternalAgentsApi
    public suspend fun onNodeExecutionStarting(
        eventId: String,
        executionInfo: AgentExecutionInfo,
        context: AIAgentGraphContextBase,
        node: AIAgentNodeBase<*, *>,
        input: Any?,
        inputType: TypeToken,
    )

    @InternalAgentsApi
    public suspend fun onNodeExecutionCompleted(
        eventId: String,
        executionInfo: AgentExecutionInfo,
        context: AIAgentGraphContextBase,
        node: AIAgentNodeBase<*, *>,
        input: Any?,
        inputType: TypeToken,
        output: Any?,
        outputType: TypeToken,
    )

    @InternalAgentsApi
    public suspend fun onNodeExecutionFailed(
        eventId: String,
        executionInfo: AgentExecutionInfo,
        context: AIAgentGraphContextBase,
        node: AIAgentNodeBase<*, *>,
        input: Any?,
        inputType: TypeToken,
        error: Throwable,
    )

    //endregion Trigger Node Handlers

    //region Trigger Subgraph Handlers

    @InternalAgentsApi
    public suspend fun onSubgraphExecutionStarting(
        eventId: String,
        executionInfo: AgentExecutionInfo,
        context: AIAgentGraphContextBase,
        subgraph: AIAgentSubgraphBase<*, *>,
        input: Any?,
        inputType: TypeToken,
    )

    @InternalAgentsApi
    public suspend fun onSubgraphExecutionCompleted(
        eventId: String,
        executionInfo: AgentExecutionInfo,
        context: AIAgentGraphContextBase,
        subgraph: AIAgentSubgraphBase<*, *>,
        input: Any?,
        inputType: TypeToken,
        output: Any?,
        outputType: TypeToken,
    )

    @InternalAgentsApi
    public suspend fun onSubgraphExecutionFailed(
        eventId: String,
        executionInfo: AgentExecutionInfo,
        context: AIAgentGraphContextBase,
        subgraph: AIAgentSubgraphBase<*, *>,
        input: Any?,
        inputType: TypeToken,
        error: Throwable,
    )

    //endregion Trigger Subgraph Handlers

    //region Interceptors

    @JvmSynthetic
    public fun interceptNodeExecutionStarting(
        feature: AIAgentGraphFeature<*, *>,
        handle: suspend (eventContext: NodeExecutionStartingContext) -> Unit
    )

    @JvmSynthetic
    public fun interceptNodeExecutionCompleted(
        feature: AIAgentGraphFeature<*, *>,
        handle: suspend (eventContext: NodeExecutionCompletedContext) -> Unit
    )

    @JvmSynthetic
    public fun interceptNodeExecutionFailed(
        feature: AIAgentGraphFeature<*, *>,
        handle: suspend (eventContext: NodeExecutionFailedContext) -> Unit
    )

    @JvmSynthetic
    public fun interceptSubgraphExecutionStarting(
        feature: AIAgentGraphFeature<*, *>,
        handle: suspend (eventContext: SubgraphExecutionStartingContext) -> Unit
    )

    @JvmSynthetic
    public fun interceptSubgraphExecutionCompleted(
        feature: AIAgentGraphFeature<*, *>,
        handle: suspend (eventContext: SubgraphExecutionCompletedContext) -> Unit
    )

    @JvmSynthetic
    public fun interceptSubgraphExecutionFailed(
        feature: AIAgentGraphFeature<*, *>,
        handle: suspend (eventContext: SubgraphExecutionFailedContext) -> Unit
    )

    //endregion Interceptors
}
