package ai.koog.agents.ext.agent

import ai.koog.agents.core.agent.context.AIAgentContext
import ai.koog.agents.core.agent.context.AIAgentGraphContextBase
import ai.koog.agents.core.agent.context.DetachedPromptExecutorAPI
import ai.koog.agents.core.agent.entity.ToolSelectionStrategy
import ai.koog.agents.core.agent.entity.createStorageKey
import ai.koog.agents.core.annotation.InternalAgentsApi
import ai.koog.agents.core.dsl.builder.AIAgentBuilderDslMarker
import ai.koog.agents.core.dsl.builder.AIAgentSubgraphBuilderBase
import ai.koog.agents.core.dsl.builder.AIAgentSubgraphDelegate
import ai.koog.agents.core.dsl.builder.node
import ai.koog.agents.core.dsl.builder.subgraph
import ai.koog.agents.core.dsl.extension.ReceivedToolResults
import ai.koog.agents.core.dsl.extension.ToolCalls
import ai.koog.agents.core.dsl.extension.nodeLLMRequest
import ai.koog.agents.core.dsl.extension.nodeLLMSendToolResults
import ai.koog.agents.core.dsl.extension.onTextMessage
import ai.koog.agents.core.dsl.extension.onToolCalls
import ai.koog.agents.core.environment.ReceivedToolResult
import ai.koog.agents.core.environment.ToolResultKind
import ai.koog.agents.core.environment.toSafeResult
import ai.koog.agents.core.tools.Tool
import ai.koog.agents.core.tools.ToolBase
import ai.koog.agents.core.tools.ToolDescriptor
import ai.koog.agents.core.tools.ToolParameterDescriptor
import ai.koog.agents.core.tools.annotations.InternalAgentToolsApi
import ai.koog.agents.core.tools.schema.getJsonSchema
import ai.koog.agents.core.tools.schema.toToolParameter
import ai.koog.prompt.llm.LLMCapability
import ai.koog.prompt.llm.LLModel
import ai.koog.prompt.message.Message
import ai.koog.prompt.message.MessagePart
import ai.koog.prompt.params.LLMParams
import ai.koog.prompt.processor.ResponseProcessor
import ai.koog.serialization.JSONElement
import ai.koog.serialization.JSONObject
import ai.koog.serialization.JSONSerializer
import ai.koog.serialization.TypeToken
import ai.koog.serialization.annotations.InternalKoogSerializationApi
import ai.koog.serialization.kotlinx.KotlinxDelegateSerializer
import ai.koog.serialization.kotlinx.KotlinxSerializer
import ai.koog.serialization.kotlinx.toKoogJSONObject
import ai.koog.serialization.kotlinx.toKotlinxJsonObject
import ai.koog.serialization.typeToken
import kotlinx.schema.generator.json.JsonSchemaConfig
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlin.coroutines.cancellation.CancellationException

/**
 * Utility object providing tools and methods for working with subgraphs and tasks in a controlled
 * and structured way. These utilities are designed to help finalize subgraph-related tasks and
 * encapsulate result handling within tool constructs.
 */
public object SubgraphWithTaskUtils {

    /**
     * Represents the name of the internal tool used for finalizing subgraph task results
     * within an AI agent's execution flow. This constant is primarily intended for internal
     * use in the implementation of tools and agents.
     *
     * Usage of this tool name is subject to the constraints and opt-in requirements
     * specified by the `InternalAgentToolsApi` annotation, indicating potential instability
     * and the possibility of breaking changes in future updates.
     *
     * Value: "finalize_task_result".
     */
    @InternalAgentToolsApi
    public const val FINALIZE_SUBGRAPH_TOOL_NAME: String = "finalize_task_result"

    /**
     * A constant string describing the purpose and usage of a tool within the agent framework.
     *
     * This constant is intended to represent the action of finalizing a subgraph process and providing
     * the final result. It is specifically used internally to indicate when a process is considered
     * complete and the output of that process should be returned.
     *
     * Marked with `@InternalAgentToolsApi`, this value is primarily designed for internal use within
     * the agent tools API and subject to change in future releases. Its usage in external
     * implementations should be approached with caution.
     */
    @InternalAgentToolsApi
    public const val FINALIZE_SUBGRAPH_TOOL_DESCRIPTION: String = "Call this tool when finish and provide final result"

    /**
     * Creates an instance of [FinishTool] for output type [T]
     */
    @OptIn(InternalAgentToolsApi::class)
    public inline fun <reified T> finishTool(): Tool<T, T> = FinishTool(typeToken<T>())

    /**
     * The maximum number of times an assistant is allowed to repeat responses within an interaction session,
     * up to a maximum of 3 times, by default.
     *
     * This constant serves as a limit to control the repetition of responses
     * provided by an assistant within interaction sessions. It can be used
     * to prevent redundancy in responses and ensure conciseness in communication.
     */
    public const val ASSISTANT_RESPONSE_REPEAT_MAX: Int = 3
}

/**
 * A pass-through tool used with [subgraphWithTask] to signal task completion and return a structured result.
 * Wraps outputs in [FinishResult] to support primitive [outputType]s, which base [Tool] cannot handle directly.
 *
 * @param outputType Type of the [Output]
 * @param customSerializer Optional serializer override to use instead of the one that is passed to encode/decode tool methods.
 * This is useful for certain internal implementations, such as some built-in subgraphs and subtasks, when the output is our own class
 * and we don't want to rely on user-configured [JSONSerializer].
 */
@OptIn(InternalAgentToolsApi::class, InternalKoogSerializationApi::class)
public class FinishTool<Output>
@InternalAgentsApi internal constructor(
    private val outputType: TypeToken,
    private val customSerializer: JSONSerializer? = null,
) : Tool<Output, Output>(
    argsType = typeToken(FinishResult::class, typeArguments = listOf(outputType)),
    resultType = typeToken(FinishResult::class, typeArguments = listOf(outputType)),
    descriptor = run {
        // Include the polymorphic discriminator so sealed Output types reach the LLM with the
        // `type` const that kotlinx-serialization requires when decoding back into a sealed instance.
        val resultSchema = getJsonSchema(outputType, JsonSchemaConfig(includePolymorphicDiscriminator = true))
        val resultToolParameter = resultSchema.toToolParameter(resultSchema.defs)

        ToolDescriptor(
            name = SubgraphWithTaskUtils.FINALIZE_SUBGRAPH_TOOL_NAME,
            description = SubgraphWithTaskUtils.FINALIZE_SUBGRAPH_TOOL_DESCRIPTION,
            requiredParameters = listOf(
                ToolParameterDescriptor(
                    name = "result",
                    description = resultToolParameter.description,
                    type = resultToolParameter.type,
                )
            )
        )
    }
) {
    private companion object {
        private val json = Json.Default
    }

    /**
     * A pass-through tool used with [subgraphWithTask] to signal task completion and return a structured result.
     * Wraps outputs in [FinishResult] to support primitive [outputType]s, which base [Tool] cannot handle directly.
     */
    @OptIn(InternalAgentsApi::class)
    public constructor(outputType: TypeToken) : this(outputType, null)

    /**
     * Wrapper for the output, since the output itself might be a primitive type, and they are not
     * supported for automatic tool descriptor generation.
     */
    @Serializable
    private data class FinishResult<Output>(
        val result: Output
    )

    private fun decodeOutput(rawArgs: JSONObject, serializer: JSONSerializer): Output {
        return json.decodeFromJsonElement<FinishResult<Output>>(
            deserializer = FinishResult.serializer(
                KotlinxDelegateSerializer(
                    customSerializer ?: serializer,
                    outputType
                )
            ),
            element = rawArgs.toKotlinxJsonObject(),
        ).result
    }

    private fun encodeOutput(args: Output, serializer: JSONSerializer): JSONObject {
        return json.encodeToJsonElement(
            serializer = FinishResult.serializer(KotlinxDelegateSerializer(customSerializer ?: serializer, outputType)),
            value = FinishResult(args)
        ).jsonObject.toKoogJSONObject()
    }

    override fun decodeArgs(rawArgs: JSONObject, serializer: JSONSerializer): Output = decodeOutput(rawArgs, serializer)

    override fun encodeArgs(args: Output, serializer: JSONSerializer): JSONObject = encodeOutput(args, serializer)

    override fun decodeResult(rawResult: JSONElement, serializer: JSONSerializer): Output =
        decodeOutput(rawResult as JSONObject, serializer)

    override fun encodeResult(result: Output, serializer: JSONSerializer): JSONElement =
        encodeOutput(result, serializer)

    override suspend fun execute(args: Output): Output = args
}

//region Subgraph With Task

/**
 * Creates a subgraph, which performs one specific task, defined by [defineTask],
 * using the tools defined by [toolSelectionStrategy].
 *
 * Use this function if you need the agent to perform a single task which outputs a structured result.
 *
 * @param Input The input type for the task to be defined in the subgraph.
 * @param Output The output type for the subgraph's finalized result.
 * @param toolSelectionStrategy The strategy used to select tools for the subgraph operations.
 * @param name An optional name for the subgraph. Defaults to null if not provided.
 * @param llmModel Optional language model to be used within the subgraph. Defaults to null.
 * @param llmParams Optional parameters for configuring the language model behavior. Defaults to null.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A suspending lambda function that defines the task for the subgraph, taking the input as a parameter.
 * @return A delegate that represents the created subgraph, allowing input and output operations.
 */
@OptIn(InternalAgentToolsApi::class, InternalAgentsApi::class)
@AIAgentBuilderDslMarker
public inline fun <reified Input, reified Output> subgraphWithTask(
    name: String? = null,
    toolSelectionStrategy: ToolSelectionStrategy = ToolSelectionStrategy.ALL,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    freshHistory: Boolean = false,
    noinline defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, Output> = subgraph(
    name = name,
    toolSelectionStrategy = toolSelectionStrategy,
    llmModel = llmModel,
    llmParams = llmParams,
    responseProcessor = responseProcessor,
    freshHistory = freshHistory,
) {
    val finishTool = FinishTool<Output>(typeToken<Output>())

    setupSubgraphWithTask(
        finishTool = finishTool,
        parallelTools = parallelTools,
        assistantResponseRepeatMax = assistantResponseRepeatMax,
        defineTask = defineTask
    )
}

/**
 * Creates a subgraph, which performs one specific task, defined by [defineTask],
 * using the tools defined by [toolSelectionStrategy].
 *
 * Use this function if you need the agent to perform a single task which outputs a structured result.
 *
 * @param Input The input type for the task to be defined in the subgraph.
 * @param Output The output type for the subgraph's finalized result.
 * @param toolSelectionStrategy The strategy used to select tools for the subgraph operations.
 * @param name An optional name for the subgraph. Defaults to null if not provided.
 * @param llmModel Optional language model to be used within the subgraph. Defaults to null.
 * @param llmParams Optional parameters for configuring the language model behavior. Defaults to null.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A suspending lambda function that defines the task for the subgraph, taking the input as a parameter.
 * @return A delegate that represents the created subgraph, allowing input and output operations.
 */
@OptIn(InternalAgentToolsApi::class, InternalAgentsApi::class)
@AIAgentBuilderDslMarker
@InternalAgentsApi
public fun <Input : Any, Output : Any> subgraphWithTask(
    name: String? = null,
    inputType: TypeToken,
    outputType: TypeToken,
    toolSelectionStrategy: ToolSelectionStrategy = ToolSelectionStrategy.ALL,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    freshHistory: Boolean = false,
    defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, Output> = subgraph(
    name = name,
    inputType = inputType,
    outputType = outputType,
    toolSelectionStrategy = toolSelectionStrategy,
    llmModel = llmModel,
    llmParams = llmParams,
    responseProcessor = responseProcessor,
    freshHistory = freshHistory,
) {
    val finishTool = FinishTool<Output>(outputType)

    setupSubgraphWithTask<Input, Output, Output>(
        finishTool = finishTool,
        inputType = inputType,
        outputTransformedType = outputType,
        parallelTools = parallelTools,
        assistantResponseRepeatMax = assistantResponseRepeatMax,
        defineTask = defineTask
    )
}

/**
 * Creates a subgraph with a task definition and specified tools. The subgraph uses the provided tools to process
 * input and execute the defined task, eventually producing a result through the provided finish tool.
 *
 * @param tools The list of tools that are available for use within the subgraph.
 * @param name An optional name for the subgraph. Defaults to null if not provided.
 * @param llmModel An optional language model to be used in the subgraph. If not specified, a default model may be used.
 * @param llmParams Optional parameters to customize the behavior of the language model in the subgraph.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A suspend function that defines the task to be executed by the subgraph based on the given input.
 * @return A delegate representing the subgraph that processes the input and produces a result through the finish tool.
 */
@AIAgentBuilderDslMarker
public inline fun <reified Input, reified Output> subgraphWithTask(
    tools: List<ToolBase<*, *>>,
    name: String? = null,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    freshHistory: Boolean = false,
    noinline defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, Output> = subgraphWithTask(
    toolSelectionStrategy = ToolSelectionStrategy.Tools(tools.map { it.descriptor }),
    name = name,
    llmModel = llmModel,
    llmParams = llmParams,
    parallelTools = parallelTools,
    assistantResponseRepeatMax = assistantResponseRepeatMax,
    responseProcessor = responseProcessor,
    freshHistory = freshHistory,
    defineTask = defineTask
)

/**
 * Defines a subgraph with a specific task to be performed by an AI agent.
 *
 * @param Input The input type provided to the subgraph.
 * @param OutputTransformed The transformed output type after finishing the task.
 * @param toolSelectionStrategy The strategy to be used for selecting tools within the subgraph.
 * @param finishTool The tool responsible for finalizing the task and producing the transformed output.
 * @param name An optional name for the subgraph. Defaults to null if not provided.
 * @param llmModel The optional language model to be used in the subgraph for processing requests.
 * @param llmParams The optional parameters to customize the behavior of the language model.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A lambda function to define the task logic, which accepts the input and returns a task description.
 * @return A delegate object representing the constructed subgraph for the specified task.
 */
@OptIn(InternalAgentsApi::class)
@AIAgentBuilderDslMarker
@InternalAgentsApi
public fun <Input : Any, OutputTransformed : Any> subgraphWithTask(
    inputType: TypeToken,
    toolSelectionStrategy: ToolSelectionStrategy,
    finishTool: Tool<*, OutputTransformed>,
    name: String? = null,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    freshHistory: Boolean = false,
    defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, OutputTransformed> = subgraph<Input, OutputTransformed>(
    inputType = inputType,
    outputType = finishTool.resultType,
    name = name,
    toolSelectionStrategy = toolSelectionStrategy,
    llmModel = llmModel,
    llmParams = llmParams,
    responseProcessor = responseProcessor,
    freshHistory = freshHistory,
) {
    setupSubgraphWithTask(
        finishTool = finishTool,
        inputType = inputType,
        outputTransformedType = finishTool.resultType,
        parallelTools = parallelTools,
        assistantResponseRepeatMax = assistantResponseRepeatMax,
        defineTask = defineTask,
    )
}

/**
 * Defines a subgraph with a specific task to be performed by an AI agent.
 *
 * @param Input The input type provided to the subgraph.
 * @param Output The output type returned by the subgraph.
 * @param OutputTransformed The transformed output type after finishing the task.
 * @param toolSelectionStrategy The strategy to be used for selecting tools within the subgraph.
 * @param finishTool The tool responsible for finalizing the task and producing the transformed output.
 * @param name An optional name for the subgraph. Defaults to null if not provided.
 * @param llmModel The optional language model to be used in the subgraph for processing requests.
 * @param llmParams The optional parameters to customize the behavior of the language model.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A lambda function to define the task logic, which accepts the input and returns a task description.
 * @return A delegate object representing the constructed subgraph for the specified task.
 */
@OptIn(InternalAgentsApi::class)
@AIAgentBuilderDslMarker
public inline fun <reified Input, reified Output, reified OutputTransformed> subgraphWithTask(
    toolSelectionStrategy: ToolSelectionStrategy,
    finishTool: Tool<Output, OutputTransformed>,
    name: String? = null,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    freshHistory: Boolean = false,
    noinline defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, OutputTransformed> = subgraph(
    name = name,
    toolSelectionStrategy = toolSelectionStrategy,
    llmModel = llmModel,
    llmParams = llmParams,
    responseProcessor = responseProcessor,
    freshHistory = freshHistory,
) {
    setupSubgraphWithTask<Input, Output, OutputTransformed>(
        finishTool = finishTool,
        parallelTools = parallelTools,
        assistantResponseRepeatMax = assistantResponseRepeatMax,
        defineTask = defineTask
    )
}

/**
 * Creates a subgraph with a specified task definition, a list of tools, and a finish tool to transform output.
 *
 * @param Input The type of the input for the subgraph task.
 * @param Output The type of the raw output produced by the finish tool.
 * @param OutputTransformed The transformed type of the output after applying the finish tool.
 * @param tools A list of tools to be used within the subgraph.
 * @param finishTool The tool responsible for transforming the output of the subgraph.
 * @param name An optional name for the subgraph. Defaults to null if not provided.
 * @param llmModel The language model to be used within the subgraph. Defaults to null if not provided.
 * @param llmParams Optional parameters to customize the behavior of the language model. Defaults to null if not provided.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A suspend function that defines the task to be executed in the subgraph, based on the provided input.
 * @return A subgraph delegate that handles the input and produces the transformed output for the defined task.
 */
@OptIn(InternalAgentsApi::class)
@AIAgentBuilderDslMarker
public inline fun <reified Input, reified Output, reified OutputTransformed> subgraphWithTask(
    tools: List<ToolBase<*, *>>,
    finishTool: Tool<Output, OutputTransformed>,
    name: String? = null,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    freshHistory: Boolean = false,
    noinline defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, OutputTransformed> = subgraph(
    name = name,
    toolSelectionStrategy = ToolSelectionStrategy.Tools(tools.map { it.descriptor }),
    llmModel = llmModel,
    llmParams = llmParams,
    responseProcessor = responseProcessor,
    freshHistory = freshHistory,
) {
    setupSubgraphWithTask<Input, Output, OutputTransformed>(
        finishTool = finishTool,
        parallelTools = parallelTools,
        assistantResponseRepeatMax = assistantResponseRepeatMax,
        defineTask = defineTask
    )
}

//endregion Subgraph With Task

//region Subgraph With Verification

/**
 * [subgraphWithTask] with [CriticResult] result.
 * It verifies if the task was performed correctly or not, and describes the problems if any.
 *
 * @param Input The input type accepted by the subgraph.
 * @param toolSelectionStrategy The strategy used to select tools for the subgraph operations.
 * @param llmModel Optional language model to be used within the subgraph. Defaults to null.
 * @param llmParams Optional parameters for configuring the language model behavior. Defaults to null.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A suspending lambda function that defines the task for the subgraph, taking the input as a parameter.
 * @return A delegate representing the constructed subgraph with verification result.
 */
@OptIn(InternalAgentsApi::class)
@Suppress("unused")
@AIAgentBuilderDslMarker
@InternalAgentsApi
public fun <Input : Any> subgraphWithVerification(
    name: String? = null,
    inputType: TypeToken,
    toolSelectionStrategy: ToolSelectionStrategy,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, CriticResult<Input>> = subgraph<Input, CriticResult<Input>>(
    name = name,
    inputType = inputType,
    outputType = typeToken<CriticResult<Input>>()
) {
    val inputKey = createStorageKey<Input>("subgraphWithVerification-input-key", inputType)

    val saveInput by node<Input, Input>(inputType = inputType, outputType = inputType) { input ->
        storage.set(inputKey, input)

        input
    }

    val verifyTask by subgraphWithTask<Input, CriticResultFromLLM>(
        inputType = inputType,
        finishTool = FinishTool<CriticResultFromLLM>(
            outputType = typeToken<CriticResultFromLLM>(),
            customSerializer = KotlinxSerializer()
        ),
        toolSelectionStrategy = toolSelectionStrategy,
        llmModel = llmModel,
        llmParams = llmParams,
        parallelTools = parallelTools,
        assistantResponseRepeatMax = assistantResponseRepeatMax,
        responseProcessor = responseProcessor,
        defineTask = defineTask
    )

    val provideResult by node<CriticResultFromLLM, CriticResult<Input>> { result ->
        CriticResult(
            successful = result.isCorrect,
            feedback = result.feedback,
            input = storage.get(inputKey)!!
        )
    }

    nodeStart then saveInput then verifyTask then provideResult then nodeFinish
}

/**
 * [subgraphWithTask] with [CriticResult] result.
 * It verifies if the task was performed correctly or not, and describes the problems if any.
 *
 * @param Input The input type accepted by the subgraph.
 * @param toolSelectionStrategy The strategy used to select tools for the subgraph operations.
 * @param llmModel Optional language model to be used within the subgraph. Defaults to null.
 * @param llmParams Optional parameters for configuring the language model behavior. Defaults to null.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A suspending lambda function that defines the task for the subgraph, taking the input as a parameter.
 * @return A delegate representing the constructed subgraph with verification result.
 */
@OptIn(InternalAgentsApi::class)
@Suppress("unused")
@AIAgentBuilderDslMarker
public inline fun <reified Input : Any> subgraphWithVerification(
    toolSelectionStrategy: ToolSelectionStrategy,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    noinline defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, CriticResult<Input>> = subgraphWithVerification(
    inputType = typeToken<Input>(),
    toolSelectionStrategy = toolSelectionStrategy,
    llmModel = llmModel,
    llmParams = llmParams,
    parallelTools = parallelTools,
    assistantResponseRepeatMax = assistantResponseRepeatMax,
    responseProcessor = responseProcessor,
    defineTask = defineTask
)

/**
 * Constructs a subgraph within an AI agent's strategy graph with additional verification capabilities.
 *
 * This method defines a subgraph using a given list of tools, an optional language model,
 * and optional language model parameters. It also allows specifying whether to summarize
 * the interaction history and defines the task to be executed in the subgraph.
 *
 * @param Input The input type accepted by the subgraph.
 * @param tools A list of tools available to the subgraph.
 * @param llmModel Optional language model to be used within the subgraph.
 * @param llmParams Optional parameters to configure the language model's behavior.
 * @param parallelTools The mode in which tools are executed. Defaults to sequential execution.
 * @param assistantResponseRepeatMax The maximum number of assistant responses allowed before determining that the task cannot be completed.
 * @param responseProcessor An optional processor defining the post-processing of messages returned from the LLM.
 * @param defineTask A suspendable function defining the task that the subgraph will execute,
 *                   which takes an input and produces a string-based task description.
 * @return A delegate representing the constructed subgraph with input type `Input` and output type
 *         as a verified subgraph result `CriticResult`.
 */
@Suppress("unused")
@AIAgentBuilderDslMarker
public inline fun <reified Input : Any> subgraphWithVerification(
    tools: List<ToolBase<*, *>>,
    llmModel: LLModel? = null,
    llmParams: LLMParams? = null,
    parallelTools: Boolean = false,
    assistantResponseRepeatMax: Int? = null,
    responseProcessor: ResponseProcessor? = null,
    noinline defineTask: suspend AIAgentGraphContextBase.(input: Input) -> String
): AIAgentSubgraphDelegate<Input, CriticResult<Input>> = subgraphWithVerification(
    toolSelectionStrategy = ToolSelectionStrategy.Tools(tools.map { it.descriptor }),
    llmModel = llmModel,
    llmParams = llmParams,
    parallelTools = parallelTools,
    assistantResponseRepeatMax = assistantResponseRepeatMax,
    responseProcessor = responseProcessor,
    defineTask = defineTask
)

//endregion Subgraph With Verification

/**
 * Configures and sets up a subgraph with task handling, including tool execution operations,
 * assistant response management, and task finalization logic.
 *
 * @param Input the type of input data for the subgraph.
 * @param Output the type of output data from the finish tool.
 * @param OutputTransformed the transformed type of the output data after processing by the finish tool.
 * @param finishTool the tool used to signify task completion and process task finalization.
 * @param parallelTools the mode in which tools are executed, e.g., parallel or sequential execution.
 * @param assistantResponseRepeatMax the maximum number of assistant responses allowed before
 *        determining that the task cannot be completed. If not provided, a default is used.
 * @param defineTask a suspend function defining the task description, executed within the
 *        context of an AI agent graph and based on the given input data.
 */
@InternalAgentsApi
public fun <Input, Output, OutputTransformed> AIAgentSubgraphBuilderBase<Input, OutputTransformed>.setupSubgraphWithTask(
    finishTool: Tool<Output, OutputTransformed>,
    inputType: TypeToken,
    outputTransformedType: TypeToken,
    parallelTools: Boolean,
    assistantResponseRepeatMax: Int? = null,
    defineTask: suspend AIAgentGraphContextBase.(Input) -> String
) {
    val originalToolsKey = createStorageKey<List<ToolDescriptor>>("all-available-tools")
    val askAssistantToFinishCounterKey = createStorageKey<Int>("ask-assistant-to-finish-counter")

    val maxAssistantResponses = assistantResponseRepeatMax ?: SubgraphWithTaskUtils.ASSISTANT_RESPONSE_REPEAT_MAX

    val setupTask by node<Input, String>(inputType = inputType, outputType = typeToken<String>()) { input ->
        llm.writeSession {
            // Save tools to restore after the subgraph is finished
            storage.set(originalToolsKey, tools)

            // Append finish tool to tools if it's not present yet
            if (finishTool.descriptor !in tools) {
                this.tools += finishTool.descriptor
            }

            // Model must always call tools in the loop until it decides (via finish tool)
            // that the exit condition is reached
            setToolChoiceRequired()
        }

        // Output task description
        defineTask(input)
    }

    val finalizeTask by node<ReceivedToolResults, OutputTransformed>(
        inputType = typeToken<ReceivedToolResult>(),
        outputType = outputTransformedType
    ) {
        llm.writeSession {
            // Append all tool results to the prompt, otherwise there will be calls without results, which is invalid
            appendPrompt {
                user {
                    it.toolResults.forEach { toolResult ->
                        toolResult(toolResult.toMessagePart())
                    }
                }
            }
            // Restore original tools
            tools = storage.get(originalToolsKey)!!
        }

        // Take the first finish tool and return as a result
        it.toolResults
            .first { it.tool == finishTool.name && it.resultKind is ToolResultKind.Success }
            .toSafeResult(finishTool, config.serializer)
            .asSuccessful()
            .result
    }

    // Helper node to overcome problems of the current api and repeat less code when writing routing conditions
    val nodeDecide by node<Message.Assistant, Message.Assistant> { it }

    val nodeCallLLM by nodeLLMRequest()

    val callToolsHacked by node<ToolCalls, ReceivedToolResults> { message ->
        val (finishToolCalls, regularToolCalls) = message.toolCalls.partition { it.tool == finishTool.name }

        // Execute regular tools
        val regularToolsResults = if (parallelTools) {
            environment.executeTools(regularToolCalls)
        } else {
            regularToolCalls.map { toolCall ->
                environment.executeTool(toolCall)
            }
        }

        // Execute finish tool
        val finishToolResult = finishToolCalls.firstOrNull()?.let { toolCall ->
            executeFinishTool(toolCall, finishTool)
        }

        ReceivedToolResults(
            buildList {
                finishToolResult?.let { add(it) }
                addAll(regularToolsResults)
            }
        )
    }

    @OptIn(DetachedPromptExecutorAPI::class) val handleAssistantMessage by node<String, Message.Assistant> { response ->
        if (llm.model.supports(LLMCapability.ToolChoice)) {
            error(
                "Subgraph with task must always call tools, but no ${MessagePart.Tool.Call::class.simpleName} was generated, " + "got instead: $response"
            )
        }

        val currentAskAssistantToFinishCounter = storage.get(askAssistantToFinishCounterKey) ?: 1
        storage.set(askAssistantToFinishCounterKey, currentAskAssistantToFinishCounter + 1)

        if (currentAskAssistantToFinishCounter > maxAssistantResponses) {
            error(
                "Unable to finish subgraph with task. Reason: the model '${llm.model.id}' does not support tool choice, " + "and was not able to call `${finishTool.name}` tool after " + "<$maxAssistantResponses> attempts."
            )
        }

        llm.writeSession {
            // append a new message to the history with feedback:
            appendPrompt {
                user(
                    "# DO NOT CHAT WITH ME DIRECTLY! CALL TOOLS, INSTEAD.\n" + "## IF YOU HAVE FINISHED, CALL `${finishTool.name}` TOOL!"
                )
            }

            requestLLM()
        }
    }
    val sendToolsResults by nodeLLMSendToolResults()

    nodeStart then setupTask
    edge(setupTask forwardTo nodeCallLLM)
    edge(nodeCallLLM forwardTo nodeDecide)

    edge(nodeDecide forwardTo callToolsHacked onToolCalls { true })

    edge(nodeDecide forwardTo handleAssistantMessage onTextMessage { true })

    edge(handleAssistantMessage forwardTo nodeDecide)

    // throw to terminate the agent early with exception
    edge(
        nodeDecide forwardTo nodeFinish transformed {
            throw IllegalStateException(
                "Unhandled response from LLM. Subgraph with task must always call tools, " + "but no ${MessagePart.Tool.Call::class.simpleName} was generated, got instead: $it"
            )
        }
    )

    edge(
        callToolsHacked forwardTo finalizeTask
            onCondition {
                it.toolResults.any { toolResult ->
                    toolResult.tool == finishTool.name &&
                        toolResult.resultKind is ToolResultKind.Success
                }
            }
    )

    callToolsHacked then sendToolsResults then nodeDecide

    edge(finalizeTask forwardTo nodeFinish)
}

/**
 * Configures and sets up a subgraph with task handling, including tool execution operations,
 * assistant response management, and task finalization logic.
 *
 * @param Input the type of input data for the subgraph.
 * @param Output the type of output data from the finish tool.
 * @param OutputTransformed the transformed type of the output data after processing by the finish tool.
 * @param finishTool the tool used to signify task completion and process task finalization.
 * @param parallelTools the mode in which tools are executed, e.g., parallel or sequential execution.
 * @param assistantResponseRepeatMax the maximum number of assistant responses allowed before
 *        determining that the task cannot be completed. If not provided, a default is used.
 * @param defineTask a suspend function defining the task description, executed within the
 *        context of an AI agent graph and based on the given input data.
 */
@InternalAgentsApi
public inline fun <reified Input, Output, reified OutputTransformed> AIAgentSubgraphBuilderBase<Input, OutputTransformed>.setupSubgraphWithTask(
    finishTool: Tool<Output, OutputTransformed>,
    parallelTools: Boolean,
    assistantResponseRepeatMax: Int? = null,
    noinline defineTask: suspend AIAgentGraphContextBase.(Input) -> String
) {
    setupSubgraphWithTask(
        finishTool = finishTool,
        inputType = typeToken<Input>(),
        outputTransformedType = typeToken<OutputTransformed>(),
        parallelTools = parallelTools,
        assistantResponseRepeatMax = assistantResponseRepeatMax,
        defineTask = defineTask,
    )
}

@PublishedApi
@InternalAgentsApi
internal suspend fun <Output, OutputTransformed> AIAgentContext.executeFinishTool(
    toolCall: MessagePart.Tool.Call,
    finishTool: Tool<Output, OutputTransformed>,
): ReceivedToolResult {
    val toolDescription = finishTool.descriptor.description
    // Execute Finish tool directly and get a result
    val (encodedResult, resultObject) = try {
        val args = finishTool.decodeArgs(toolCall.argsJson.toKoogJSONObject(), config.serializer)
        val toolResult = finishTool.execute(args = args)
        finishTool.encodeResult(toolResult, config.serializer) to toolResult
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        return ReceivedToolResult(
            id = toolCall.id,
            tool = finishTool.name,
            toolArgs = runCatching { toolCall.argsJson.toKoogJSONObject() }.getOrElse { JSONObject(emptyMap()) },
            toolDescription = toolDescription,
            output = "Failed to execute '${finishTool.name}' with error: ${e.message}'",
            resultKind = ToolResultKind.Failure(e),
            result = null,
            resultObject = null
        )
    }

    return ReceivedToolResult(
        id = toolCall.id,
        tool = finishTool.name,
        toolArgs = toolCall.argsJson.toKoogJSONObject(),
        output = toolCall.args,
        resultKind = ToolResultKind.Success,
        toolDescription = toolDescription,
        result = encodedResult,
        resultObject = resultObject,
    )
}
